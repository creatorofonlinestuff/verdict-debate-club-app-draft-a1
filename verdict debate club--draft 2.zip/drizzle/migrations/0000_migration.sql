-- Verdict Support schema
create extension if not exists pgcrypto with schema extensions;

create type public.app_role as enum ('admin', 'mentor', 'student');

create table public.clubs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  email text,
  created_at timestamptz not null default now()
);

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  club_id uuid references public.clubs(id) on delete cascade not null,
  is_owner boolean not null default false,
  created_at timestamptz not null default now(),
  unique (user_id, role, club_id)
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  club_id uuid references public.clubs(id) on delete cascade not null,
  display_name text not null,
  year_group text not null,
  status text not null default 'active' check (status in ('active','archived')),
  joined_user_id uuid,
  current_goal text,
  interests text,
  created_by uuid,
  created_at timestamptz not null default now()
);
create index students_joined_user_idx on public.students(joined_user_id);
create index students_club_idx on public.students(club_id);

create table public.invitations (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references public.students(id) on delete cascade not null,
  club_id uuid references public.clubs(id) on delete cascade not null,
  code_hash text not null unique,
  expires_at timestamptz not null,
  used_at timestamptz,
  redeemed_by uuid,
  revoked_at timestamptz,
  created_by uuid,
  created_at timestamptz not null default now()
);
create index invitations_student_idx on public.invitations(student_id);

create table public.debate_sessions (
  id uuid primary key default gen_random_uuid(),
  club_id uuid references public.clubs(id) on delete cascade not null,
  motion text not null,
  debate_date date not null,
  format text,
  notes text,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table public.debate_participants (
  id uuid primary key default gen_random_uuid(),
  debate_id uuid references public.debate_sessions(id) on delete cascade not null,
  student_id uuid references public.students(id) on delete cascade not null,
  role text,
  created_at timestamptz not null default now(),
  unique (debate_id, student_id)
);

create table public.skill_observations (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references public.students(id) on delete cascade not null,
  debate_id uuid references public.debate_sessions(id) on delete cascade,
  observed_on date not null,
  skill text not null,
  rating integer check (rating between 1 and 5),
  note text,
  observed_by uuid,
  created_at timestamptz not null default now()
);
create index skill_obs_student_idx on public.skill_observations(student_id);

create table public.feedback (
  id uuid primary key default gen_random_uuid(),
  club_id uuid references public.clubs(id) on delete cascade not null,
  student_id uuid references public.students(id) on delete cascade not null,
  debate_id uuid references public.debate_sessions(id) on delete set null,
  skill text,
  body text not null,
  author_id uuid,
  created_at timestamptz not null default now()
);
create index feedback_student_idx on public.feedback(student_id);

create table public.motions (
  id uuid primary key default gen_random_uuid(),
  club_id uuid references public.clubs(id) on delete cascade not null,
  text text not null,
  category text,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table public.motion_assignments (
  id uuid primary key default gen_random_uuid(),
  motion_id uuid references public.motions(id) on delete cascade not null,
  student_id uuid references public.students(id) on delete cascade not null,
  assigned_by uuid,
  due_date date,
  status text not null default 'open' check (status in ('open','done')),
  assigned_at timestamptz not null default now()
);

create table public.reflections (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references public.students(id) on delete cascade not null,
  club_id uuid references public.clubs(id) on delete cascade not null,
  body text not null,
  response text,
  responded_by uuid,
  responded_at timestamptz,
  created_at timestamptz not null default now()
);
create index reflections_student_idx on public.reflections(student_id);

create table public.mentor_invitations (
  id uuid primary key default gen_random_uuid(),
  club_id uuid references public.clubs(id) on delete cascade not null,
  code_hash text not null unique,
  expires_at timestamptz not null,
  used_at timestamptz,
  redeemed_by uuid,
  revoked_at timestamptz,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table public.redemption_attempts (
  id uuid primary key default gen_random_uuid(),
  attempt_key text not null,
  submitted_hash text not null,
  success boolean not null,
  created_at timestamptz not null default now()
);
create index redemption_attempts_key_idx on public.redemption_attempts(attempt_key, created_at);

create table public.app_settings (
  id text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

insert into public.app_settings (id, value)
values ('setup_code_hash', encode(extensions.digest('VDT-FOUNDER-7391', 'sha256'), 'hex'))
on conflict (id) do nothing;

create or replace function public.has_role(_user_id uuid, _role text, _club_id uuid default null)
returns boolean
language sql stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles ur
    where ur.user_id = _user_id
      and ur.role = _role::public.app_role
      and (_club_id is null or ur.club_id = _club_id)
  )
$$;

create or replace function public.guard_student_update()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.joined_user_id is distinct from old.joined_user_id
     or new.display_name is distinct from old.display_name
     or new.year_group is distinct from old.year_group
     or new.status is distinct from old.status
     or new.club_id is distinct from old.club_id
     or new.created_by is distinct from old.created_by then
    if not coalesce(public.has_role(auth.uid(), 'mentor', old.club_id), false) then
      raise exception 'Students may only update their own goal and interests';
    end if;
  end if;
  return new;
end $$;

create trigger guard_student_update before update on public.students
for each row execute function public.guard_student_update();

grant select on public.clubs to authenticated;
grant all on public.clubs to service_role;
grant select, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
grant select, insert, update, delete on public.students to authenticated;
grant all on public.students to service_role;
grant select, insert, update, delete on public.invitations to authenticated;
grant all on public.invitations to service_role;
grant select, insert, update, delete on public.debate_sessions to authenticated;
grant all on public.debate_sessions to service_role;
grant select, insert, update, delete on public.debate_participants to authenticated;
grant all on public.debate_participants to service_role;
grant select, insert, update, delete on public.skill_observations to authenticated;
grant all on public.skill_observations to service_role;
grant select, insert, update, delete on public.feedback to authenticated;
grant all on public.feedback to service_role;
grant select, insert, update, delete on public.motions to authenticated;
grant all on public.motions to service_role;
grant select, insert, update, delete on public.motion_assignments to authenticated;
grant all on public.motion_assignments to service_role;
grant select, insert, update, delete on public.reflections to authenticated;
grant all on public.reflections to service_role;
grant select, insert, update, delete on public.mentor_invitations to authenticated;
grant all on public.mentor_invitations to service_role;
grant all on public.redemption_attempts to service_role;
grant all on public.app_settings to service_role;

alter table public.clubs enable row level security;
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.students enable row level security;
alter table public.invitations enable row level security;
alter table public.debate_sessions enable row level security;
alter table public.debate_participants enable row level security;
alter table public.skill_observations enable row level security;
alter table public.feedback enable row level security;
alter table public.motions enable row level security;
alter table public.motion_assignments enable row level security;
alter table public.reflections enable row level security;
alter table public.mentor_invitations enable row level security;
alter table public.redemption_attempts enable row level security;
alter table public.app_settings enable row level security;

create policy "club members can read club" on public.clubs
for select to authenticated
using (public.has_role(auth.uid(), 'mentor', id) or public.has_role(auth.uid(), 'admin', id) or public.has_role(auth.uid(), 'student', id));

create policy "read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "read own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create policy "mentors manage club students" on public.students for all to authenticated
using (public.has_role(auth.uid(), 'mentor', club_id))
with check (public.has_role(auth.uid(), 'mentor', club_id));
create policy "students read own record" on public.students for select to authenticated
using (joined_user_id = auth.uid());
create policy "students update own goal" on public.students for update to authenticated
using (joined_user_id = auth.uid()) with check (joined_user_id = auth.uid());

create policy "mentors manage invitations" on public.invitations for all to authenticated
using (public.has_role(auth.uid(), 'mentor', club_id))
with check (public.has_role(auth.uid(), 'mentor', club_id));

create policy "mentors manage debates" on public.debate_sessions for all to authenticated
using (public.has_role(auth.uid(), 'mentor', club_id))
with check (public.has_role(auth.uid(), 'mentor', club_id));
create policy "students view own debates" on public.debate_sessions for select to authenticated
using (exists (
  select 1 from public.debate_participants dp
  join public.students s on s.id = dp.student_id
  where dp.debate_id = debate_sessions.id and s.joined_user_id = auth.uid()
));

create policy "mentors manage participants" on public.debate_participants for all to authenticated
using (public.has_role(auth.uid(), 'mentor', (select d.club_id from public.debate_sessions d where d.id = debate_participants.debate_id)))
with check (public.has_role(auth.uid(), 'mentor', (select d.club_id from public.debate_sessions d where d.id = debate_participants.debate_id)));
create policy "students view own participation" on public.debate_participants for select to authenticated
using (exists (
  select 1 from public.students s where s.id = student_id and s.joined_user_id = auth.uid()
));

create policy "mentors manage observations" on public.skill_observations for all to authenticated
using (public.has_role(auth.uid(), 'mentor', (select s.club_id from public.students s where s.id = skill_observations.student_id)))
with check (public.has_role(auth.uid(), 'mentor', (select s.club_id from public.students s where s.id = skill_observations.student_id)));
create policy "students view own observations" on public.skill_observations for select to authenticated
using (exists (
  select 1 from public.students s where s.id = student_id and s.joined_user_id = auth.uid()
));

create policy "mentors manage feedback" on public.feedback for all to authenticated
using (public.has_role(auth.uid(), 'mentor', club_id))
with check (public.has_role(auth.uid(), 'mentor', club_id));
create policy "students read own feedback" on public.feedback for select to authenticated
using (exists (
  select 1 from public.students s where s.id = student_id and s.joined_user_id = auth.uid()
));

create policy "mentors manage motions" on public.motions for all to authenticated
using (public.has_role(auth.uid(), 'mentor', club_id))
with check (public.has_role(auth.uid(), 'mentor', club_id));
create policy "students view assigned motions" on public.motions for select to authenticated
using (exists (
  select 1 from public.motion_assignments ma
  join public.students s on s.id = ma.student_id
  where ma.motion_id = motions.id and s.joined_user_id = auth.uid()
));

create policy "mentors manage assignments" on public.motion_assignments for all to authenticated
using (public.has_role(auth.uid(), 'mentor', (select m.club_id from public.motions m where m.id = motion_assignments.motion_id)))
with check (public.has_role(auth.uid(), 'mentor', (select m.club_id from public.motions m where m.id = motion_assignments.motion_id)));
create policy "students view own assignments" on public.motion_assignments for select to authenticated
using (exists (
  select 1 from public.students s where s.id = student_id and s.joined_user_id = auth.uid()
));

create policy "students submit own reflection" on public.reflections for insert to authenticated
with check (exists (
  select 1 from public.students s where s.id = student_id and s.joined_user_id = auth.uid()
));
create policy "participants read reflection" on public.reflections for select to authenticated
using (
  exists (select 1 from public.students s where s.id = student_id and s.joined_user_id = auth.uid())
  or public.has_role(auth.uid(), 'mentor', club_id)
);
create policy "mentors respond to reflections" on public.reflections for update to authenticated
using (public.has_role(auth.uid(), 'mentor', club_id))
with check (public.has_role(auth.uid(), 'mentor', club_id));
create policy "mentors delete reflections" on public.reflections for delete to authenticated
using (public.has_role(auth.uid(), 'mentor', club_id));

create policy "mentors manage mentor invites" on public.mentor_invitations for all to authenticated
using (public.has_role(auth.uid(), 'mentor', club_id))
with check (public.has_role(auth.uid(), 'mentor', club_id));