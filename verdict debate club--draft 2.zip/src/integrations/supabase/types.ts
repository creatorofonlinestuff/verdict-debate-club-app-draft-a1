export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          id: string
          updated_at: string
          value: string
        }
        Insert: {
          id: string
          updated_at?: string
          value: string
        }
        Update: {
          id?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      clubs: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      debate_participants: {
        Row: {
          created_at: string
          debate_id: string
          id: string
          role: string | null
          student_id: string
        }
        Insert: {
          created_at?: string
          debate_id: string
          id?: string
          role?: string | null
          student_id: string
        }
        Update: {
          created_at?: string
          debate_id?: string
          id?: string
          role?: string | null
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "debate_participants_debate_id_fkey"
            columns: ["debate_id"]
            isOneToOne: false
            referencedRelation: "debate_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "debate_participants_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      debate_sessions: {
        Row: {
          club_id: string
          created_at: string
          created_by: string | null
          debate_date: string
          format: string | null
          id: string
          motion: string
          notes: string | null
        }
        Insert: {
          club_id: string
          created_at?: string
          created_by?: string | null
          debate_date: string
          format?: string | null
          id?: string
          motion: string
          notes?: string | null
        }
        Update: {
          club_id?: string
          created_at?: string
          created_by?: string | null
          debate_date?: string
          format?: string | null
          id?: string
          motion?: string
          notes?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "debate_sessions_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
        ]
      }
      feedback: {
        Row: {
          author_id: string | null
          body: string
          club_id: string
          created_at: string
          debate_id: string | null
          id: string
          skill: string | null
          student_id: string
        }
        Insert: {
          author_id?: string | null
          body: string
          club_id: string
          created_at?: string
          debate_id?: string | null
          id?: string
          skill?: string | null
          student_id: string
        }
        Update: {
          author_id?: string | null
          body?: string
          club_id?: string
          created_at?: string
          debate_id?: string | null
          id?: string
          skill?: string | null
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "feedback_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "feedback_debate_id_fkey"
            columns: ["debate_id"]
            isOneToOne: false
            referencedRelation: "debate_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "feedback_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      invitations: {
        Row: {
          club_id: string
          code_hash: string
          created_at: string
          created_by: string | null
          expires_at: string
          id: string
          redeemed_by: string | null
          revoked_at: string | null
          student_id: string
          used_at: string | null
        }
        Insert: {
          club_id: string
          code_hash: string
          created_at?: string
          created_by?: string | null
          expires_at: string
          id?: string
          redeemed_by?: string | null
          revoked_at?: string | null
          student_id: string
          used_at?: string | null
        }
        Update: {
          club_id?: string
          code_hash?: string
          created_at?: string
          created_by?: string | null
          expires_at?: string
          id?: string
          redeemed_by?: string | null
          revoked_at?: string | null
          student_id?: string
          used_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invitations_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invitations_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      mentor_invitations: {
        Row: {
          club_id: string
          code_hash: string
          created_at: string
          created_by: string | null
          expires_at: string
          id: string
          redeemed_by: string | null
          revoked_at: string | null
          used_at: string | null
        }
        Insert: {
          club_id: string
          code_hash: string
          created_at?: string
          created_by?: string | null
          expires_at: string
          id?: string
          redeemed_by?: string | null
          revoked_at?: string | null
          used_at?: string | null
        }
        Update: {
          club_id?: string
          code_hash?: string
          created_at?: string
          created_by?: string | null
          expires_at?: string
          id?: string
          redeemed_by?: string | null
          revoked_at?: string | null
          used_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "mentor_invitations_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
        ]
      }
      motion_assignments: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          due_date: string | null
          id: string
          motion_id: string
          status: string
          student_id: string
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          due_date?: string | null
          id?: string
          motion_id: string
          status?: string
          student_id: string
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          due_date?: string | null
          id?: string
          motion_id?: string
          status?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "motion_assignments_motion_id_fkey"
            columns: ["motion_id"]
            isOneToOne: false
            referencedRelation: "motions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "motion_assignments_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      motions: {
        Row: {
          category: string | null
          club_id: string
          created_at: string
          created_by: string | null
          id: string
          text: string
        }
        Insert: {
          category?: string | null
          club_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          text: string
        }
        Update: {
          category?: string | null
          club_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          text?: string
        }
        Relationships: [
          {
            foreignKeyName: "motions_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string
          email: string | null
          id: string
        }
        Insert: {
          created_at?: string
          display_name: string
          email?: string | null
          id: string
        }
        Update: {
          created_at?: string
          display_name?: string
          email?: string | null
          id?: string
        }
        Relationships: []
      }
      redemption_attempts: {
        Row: {
          attempt_key: string
          created_at: string
          id: string
          submitted_hash: string
          success: boolean
        }
        Insert: {
          attempt_key: string
          created_at?: string
          id?: string
          submitted_hash: string
          success: boolean
        }
        Update: {
          attempt_key?: string
          created_at?: string
          id?: string
          submitted_hash?: string
          success?: boolean
        }
        Relationships: []
      }
      reflections: {
        Row: {
          body: string
          club_id: string
          created_at: string
          id: string
          responded_at: string | null
          responded_by: string | null
          response: string | null
          student_id: string
        }
        Insert: {
          body: string
          club_id: string
          created_at?: string
          id?: string
          responded_at?: string | null
          responded_by?: string | null
          response?: string | null
          student_id: string
        }
        Update: {
          body?: string
          club_id?: string
          created_at?: string
          id?: string
          responded_at?: string | null
          responded_by?: string | null
          response?: string | null
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reflections_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reflections_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      skill_observations: {
        Row: {
          created_at: string
          debate_id: string | null
          id: string
          note: string | null
          observed_by: string | null
          observed_on: string
          rating: number | null
          skill: string
          student_id: string
        }
        Insert: {
          created_at?: string
          debate_id?: string | null
          id?: string
          note?: string | null
          observed_by?: string | null
          observed_on: string
          rating?: number | null
          skill: string
          student_id: string
        }
        Update: {
          created_at?: string
          debate_id?: string | null
          id?: string
          note?: string | null
          observed_by?: string | null
          observed_on?: string
          rating?: number | null
          skill?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "skill_observations_debate_id_fkey"
            columns: ["debate_id"]
            isOneToOne: false
            referencedRelation: "debate_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "skill_observations_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      students: {
        Row: {
          club_id: string
          created_at: string
          created_by: string | null
          current_goal: string | null
          display_name: string
          id: string
          interests: string | null
          joined_user_id: string | null
          status: string
          year_group: string
        }
        Insert: {
          club_id: string
          created_at?: string
          created_by?: string | null
          current_goal?: string | null
          display_name: string
          id?: string
          interests?: string | null
          joined_user_id?: string | null
          status?: string
          year_group: string
        }
        Update: {
          club_id?: string
          created_at?: string
          created_by?: string | null
          current_goal?: string | null
          display_name?: string
          id?: string
          interests?: string | null
          joined_user_id?: string | null
          status?: string
          year_group?: string
        }
        Relationships: [
          {
            foreignKeyName: "students_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          club_id: string
          created_at: string
          id: string
          is_owner: boolean
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          club_id: string
          created_at?: string
          id?: string
          is_owner?: boolean
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          club_id?: string
          created_at?: string
          id?: string
          is_owner?: boolean
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: { _club_id?: string; _role: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "mentor" | "student"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "mentor", "student"],
    },
  },
} as const
