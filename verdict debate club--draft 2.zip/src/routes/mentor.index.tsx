import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { getDashboard } from "@/lib/api/mentor.functions";
import { EmptyState, PageHeader, StatCard, formatDate } from "@/components/verdict";

export const Route = createFileRoute("/mentor/")({
  head: () => ({
    meta: [
      { title: "Mentor dashboard — Verdict Support" },
      { name: "description", content: "Review your club's debate activity and student progress." },
      { property: "og:title", content: "Mentor dashboard — Verdict Support" },
      { property: "og:description", content: "Review your club's debate activity and student progress." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) =>
    context.queryClient.ensureQueryData(
      queryOptions({ queryKey: ["mentor-dashboard"], queryFn: () => getDashboard() }),
    ),
  errorComponent: ({ error }) => (
    <div role="alert" className="text-destructive">
      {error instanceof Error ? error.message : "Couldn't load the dashboard."}
    </div>
  ),
  component: MentorDashboard,
});

function MentorDashboard() {
  const { data } = useSuspenseQuery(
    queryOptions({ queryKey: ["mentor-dashboard"], queryFn: () => getDashboard() }),
  );

  return (
    <div>
      <PageHeader
        title="Dashboard"
        subtitle={data.clubName ? `Club: ${data.clubName}` : undefined}
      >
        <Link to="/mentor/students" className="inline-flex items-center rounded-md bg-teal px-4 py-2 text-sm font-medium text-teal-foreground transition-colors hover:bg-teal/90">
          View students
        </Link>
      </PageHeader>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard
          label="Active students"
          value={data.activeStudents}
          hint={
            data.unclaimedInvitations > 0
              ? `${data.unclaimedInvitations} ${data.unclaimedInvitations === 1 ? "invitation" : "invitations"} not yet used`
              : undefined
          }
        />
        <StatCard label="Awaiting your feedback" value={data.awaitingFeedback} hint="Student reflections with no response yet" />
        <StatCard label="Upcoming debates" value={data.upcoming.length} />
      </div>

      <section className="mt-8">
        <h2 className="text-[17px] font-semibold text-foreground">Upcoming debates</h2>
        {data.upcoming.length === 0 ? (
          <div className="mt-3">
            <EmptyState
              title="Nothing scheduled yet"
              message="You haven't scheduled any debates. Add your first student and record your first debate when you're ready."
            >
              <Link to="/mentor/students" className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90">
                Add a student
              </Link>
            </EmptyState>
          </div>
        ) : (
          <ul className="mt-3 divide-y divide-border rounded-lg border border-border bg-card">
            {data.upcoming.map((d) => (
              <li key={d.id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-4">
                <div>
                  <p className="font-medium text-foreground">{d.motion}</p>
                  <p className="mt-0.5 text-[13px] text-muted-foreground">
                    {formatDate(d.debate_date)}
                    {d.format ? ` · ${d.format}` : ""}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
