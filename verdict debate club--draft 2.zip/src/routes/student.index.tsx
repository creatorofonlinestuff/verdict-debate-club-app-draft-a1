import { createFileRoute } from "@tanstack/react-router";
import type { ViewerRole } from "@/lib/guards";
import { EmptyState, PageHeader } from "@/components/verdict";

export const Route = createFileRoute("/student/")({
  head: () => ({
    meta: [
      { title: "Student home — Verdict Support" },
      { name: "description", content: "View your debate activity and mentor feedback in Verdict Support." },
      { property: "og:title", content: "Student home — Verdict Support" },
      { property: "og:description", content: "View your debate activity and mentor feedback in Verdict Support." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: StudentHome,
});

function StudentHome() {
  const { viewer } = Route.useRouteContext() as { viewer: ViewerRole };

  return (
    <div>
      <PageHeader
        title={`Hi, ${viewer.displayName || "there"}`}
        subtitle={viewer.clubName ? `Club: ${viewer.clubName}` : undefined}
      />

      <section className="rounded-lg border border-border bg-card p-5">
        <h2 className="text-[17px] font-semibold text-foreground">Debates</h2>
        <div className="mt-4">
          <EmptyState
            title="No debates yet"
            message="Your mentor has not added a debate for you yet. When they do, it will appear here."
          />
        </div>
      </section>

      <section className="mt-6 rounded-lg border border-border bg-card p-5">
        <h2 className="text-[17px] font-semibold text-foreground">Feedback</h2>
        <div className="mt-4">
          <EmptyState
            title="No feedback yet"
            message="Your mentor has not written any feedback for you yet. It will appear here after your debates."
          />
        </div>
      </section>
    </div>
  );
}
