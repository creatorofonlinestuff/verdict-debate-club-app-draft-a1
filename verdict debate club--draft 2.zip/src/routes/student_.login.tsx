import { createFileRoute, Link } from "@tanstack/react-router";
import { AuthShell, SignInForm } from "@/components/auth";

export const Route = createFileRoute("/student_/login")({
  head: () => ({
    meta: [
      { title: "Student sign-in — Verdict Support" },
      { name: "description", content: "Sign in to your Verdict Support student portal." },
      { property: "og:title", content: "Student sign-in — Verdict Support" },
      { property: "og:description", content: "Sign in to your Verdict Support student portal." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: StudentLogin,
});

function StudentLogin() {
  return (
    <AuthShell
      title="Student sign-in"
      subtitle="Welcome back. Sign in to see your progress."
      footer={
        <>
          Haven't joined yet?{" "}
          <Link to="/join" className="font-medium text-foreground underline underline-offset-4">
            Join with your code
          </Link>
          {" · "}
          <Link to="/" className="hover:text-foreground">
            Back to home
          </Link>
        </>
      }
    >
      <SignInForm portal="student" />
    </AuthShell>
  );
}
