import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Verdict Support — Debate club" },
      { name: "description", content: "Choose the Verdict Support mentor or student portal." },
      { property: "og:title", content: "Verdict Support — Debate club" },
      { property: "og:description", content: "Reflect, improve and debate with purpose." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

function PortalCard({
  to,
  title,
  description,
  className,
}: {
  to: "/mentor/login" | "/student/login";
  title: string;
  description: string;
  className: string;
}) {
  return (
    <Link
      to={to}
      className={
        "block rounded-xl p-7 text-left shadow-sm transition-transform hover:-translate-y-0.5 " +
        className
      }
    >
      <h2 className="text-xl font-bold">{title}</h2>
      <p className="mt-2 text-[15px] opacity-90">{description}</p>
      <span className="mt-5 inline-block text-sm font-semibold underline underline-offset-4">
        Sign in →
      </span>
    </Link>
  );
}

function Index() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 py-16">
      <div className="w-full max-w-2xl">
        <div className="text-center">
          <p className="text-[13px] font-semibold uppercase tracking-[0.2em] text-teal">
            Debate club tracking
          </p>
          <h1 className="mt-2 text-5xl font-bold tracking-tight text-foreground">
            Verdict Support
          </h1>
          <p className="mt-3 text-[17px] text-muted-foreground">
            Reflect, improve and debate with purpose.
          </p>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2">
          <PortalCard
            to="/mentor/login"
            title="Mentors"
            description="Add students, run debates and record progress from scratch."
            className="bg-sidebar text-sidebar-foreground"
          />
          <PortalCard
            to="/student/login"
            title="Students"
            description="See your debates, feedback and reflections in one place."
            className="bg-teal text-teal-foreground"
          />
        </div>

        <p className="mt-10 text-center text-sm text-muted-foreground">
          First time here?{" "}
          <Link to="/mentor/setup" className="font-medium text-foreground underline underline-offset-4">
            Set up your club
          </Link>
          {" · "}Have an invitation code?{" "}
          <Link to="/join" className="font-medium text-foreground underline underline-offset-4">
            Join your club
          </Link>
        </p>
      </div>
    </div>
  );
}
