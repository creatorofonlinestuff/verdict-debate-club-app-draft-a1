import { Link, Outlet, createFileRoute } from "@tanstack/react-router";
import { requireMentor, type ViewerRole } from "@/lib/guards";
import { useSignOut } from "@/components/auth";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/mentor")({
  ssr: false,
  beforeLoad: async () => ({ viewer: await requireMentor() }),
  component: MentorLayout,
});

const NAV = [
  { to: "/mentor" as const, label: "Dashboard" },
  { to: "/mentor/students" as const, label: "Students" },
];

function MentorLayout() {
  const { viewer } = Route.useRouteContext();
  const signOut = useSignOut("/mentor/login");

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-sidebar-border bg-sidebar text-sidebar-foreground">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
          <Link to="/mentor" className="text-[15px] font-bold tracking-tight">
            Verdict Support
          </Link>
          <span className="text-sm text-sidebar-foreground/70">{viewer.clubName}</span>
          <nav className="flex items-center gap-1">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="rounded-md px-3 py-1.5 text-sm font-medium text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                activeProps={{ className: "bg-sidebar-accent text-sidebar-accent-foreground" }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <Button
            variant="ghost"
            size="sm"
            className="ml-auto text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={signOut}
          >
            Sign out
          </Button>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
}
