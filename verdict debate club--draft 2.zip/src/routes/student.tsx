import { Link, Outlet, createFileRoute } from "@tanstack/react-router";
import { requireStudent, type ViewerRole } from "@/lib/guards";
import { useSignOut } from "@/components/auth";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/student")({
  ssr: false,
  beforeLoad: async () => ({ viewer: await requireStudent() }),
  component: StudentLayout,
});

function StudentLayout() {
  const { viewer } = Route.useRouteContext() as { viewer: ViewerRole };
  const signOut = useSignOut("/student/login");

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-sidebar-border bg-sidebar text-sidebar-foreground">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
          <Link to="/student" className="text-[15px] font-bold tracking-tight">
            Verdict Support
          </Link>
          <span className="text-sm text-sidebar-foreground/70">{viewer.clubName}</span>
          <Button
            variant="ghost"
            size="sm"
            className="ml-auto text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={signOut}
          >
            Sign out
          </Button>
        </div>
      </header>
      <main className="mx-auto max-w-4xl px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
}
