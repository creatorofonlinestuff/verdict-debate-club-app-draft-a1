import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { redeemStudentInvitation } from "@/lib/api/auth.functions";
import { AuthShell, Field, errorMessage } from "@/components/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/join")({
  head: () => ({
    meta: [
      { title: "Join your club — Verdict Support" },
      { name: "description", content: "Use your invitation code to join your debate club." },
      { property: "og:title", content: "Join your club — Verdict Support" },
      { property: "og:description", content: "Use your invitation code to join your debate club." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Join,
});

function Join() {
  const navigate = useNavigate();
  const [code, setCode] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await redeemStudentInvitation({ data: { code: code.trim(), email, password } });
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      if (signInError) {
        await navigate({ to: "/student/login" });
        return;
      }
      await navigate({ to: "/student" });
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell
      title="Join your club"
      subtitle="Enter the 6-digit code your mentor gave you, then choose your own email and password."
      footer={
        <>
          Already joined?{" "}
          <Link to="/student/login" className="font-medium text-foreground underline underline-offset-4">
            Sign in
          </Link>
          {" · "}
          <Link to="/" className="hover:text-foreground">
            Back to home
          </Link>
        </>
      }
    >
      <form onSubmit={handleSubmit}>
        <Field label="Invitation code" hint="6 digits, from your mentor. Each code works once.">
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
            inputMode="numeric"
            placeholder="······"
            className="text-center text-2xl font-bold tracking-[0.4em]"
            required
          />
        </Field>
        <Field label="Your email">
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            required
          />
        </Field>
        <Field label="Choose a password" hint="At least 8 characters. You'll use this to sign in.">
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
            required
          />
        </Field>
        {error ? <p className="mb-4 text-sm text-destructive">{error}</p> : null}
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Joining…" : "Join my club"}
        </Button>
      </form>
    </AuthShell>
  );
}
