import * as React from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import {
  queryOptions,
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  addFeedback,
  addObservation,
  deleteFeedback,
  deleteObservation,
  deleteStudent,
  getStudentDetail,
  respondToReflection,
  setStudentStatus,
  updateStudent,
} from "@/lib/api/mentor.functions";
import { Badge, ConfirmDialog, EmptyState, PageHeader, SKILL_OPTIONS, YEAR_GROUPS, formatDate } from "@/components/verdict";
import { errorMessage } from "@/components/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/mentor/students/$id")({
  head: () => ({
    meta: [
      { title: "Student profile — Verdict Support" },
      { name: "description", content: "Review a student's debate history, observations, reflections and feedback." },
      { property: "og:title", content: "Student profile — Verdict Support" },
      { property: "og:description", content: "Review a student's debate history, observations, reflections and feedback." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ params, context }) =>
    context.queryClient.ensureQueryData(
      queryOptions({
        queryKey: ["mentor-student", params.id],
        queryFn: () => getStudentDetail({ data: { studentId: params.id } }),
      }),
    ),
  errorComponent: ({ error }) => (
    <div role="alert" className="text-destructive">
      {error instanceof Error ? error.message : "Couldn't load this student."}
    </div>
  ),
  notFoundComponent: () => <EmptyState title="Student not found" message="This student isn't in your club." />,
  component: StudentDetailPage,
});

type Detail = Awaited<ReturnType<typeof getStudentDetail>>;
type SessionInfo = { id: string; motion: string; debate_date: string; format: string | null };

function firstOf<T>(value: T | T[] | null | undefined): T | null {
  return Array.isArray(value) ? (value[0] ?? null) : (value ?? null);
}

function Card({ title, children, action }: { title: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <section className="mt-8 rounded-lg border border-border bg-card p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-[17px] font-semibold text-foreground">{title}</h2>
        {action}
      </div>
      {children}
    </section>
  );
}

function StudentDetailPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data } = useSuspenseQuery(
    queryOptions({
      queryKey: ["mentor-student", id],
      queryFn: () => getStudentDetail({ data: { studentId: id } }),
    }),
  );

  const student = data.student as {
    id: string;
    display_name: string;
    year_group: string;
    status: string;
    joined_user_id: string | null;
    current_goal: string | null;
    interests: string | null;
  };

  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: ["mentor-student", id] });
    void queryClient.invalidateQueries({ queryKey: ["mentor-students"] });
  };

  const updateFn = useServerFn(updateStudent);
  const setStatusFn = useServerFn(setStudentStatus);
  const deleteFn = useServerFn(deleteStudent);

  const [editOpen, setEditOpen] = React.useState(false);
  const [editName, setEditName] = React.useState(student.display_name);
  const [editYear, setEditYear] = React.useState(student.year_group);
  const [deleteOpen, setDeleteOpen] = React.useState(false);

  const updateMutation = useMutation({
    mutationFn: () => updateFn({ data: { studentId: id, displayName: editName, yearGroup: editYear } }),
    onSuccess: () => {
      setEditOpen(false);
      toast.success("Details saved.");
      refresh();
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  const statusMutation = useMutation({
    mutationFn: (status: "active" | "archived") => setStatusFn({ data: { studentId: id, status } }),
    onSuccess: () => {
      toast.success("Saved.");
      refresh();
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  const deleteMutation = useMutation({
    mutationFn: () => deleteFn({ data: { studentId: id, confirmName: student.display_name } }),
    onSuccess: async () => {
      toast.success("Student deleted.");
      await queryClient.invalidateQueries({ queryKey: ["mentor-students"] });
      await navigate({ to: "/mentor/students" });
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  const joined = !!student.joined_user_id;
  const subtitle =
    student.status === "archived"
      ? "Archived — hidden from the active list."
      : joined
        ? `Joined`
        : data.activeInviteExpiresAt
          ? `Invitation active until ${formatDate(data.activeInviteExpiresAt)}`
          : "No active invitation code";

  return (
    <div>
      <Link to="/mentor/students" className="text-sm text-muted-foreground hover:text-foreground">
        ← All students
      </Link>
      <div className="mt-3">
        <PageHeader
          title={student.display_name}
          subtitle={subtitle}
        >
          <Button variant="outline" onClick={() => setEditOpen(true)}>
            Edit details
          </Button>
          {student.status === "archived" ? (
            <Button variant="outline" onClick={() => statusMutation.mutate("active")} disabled={statusMutation.isPending}>
              Restore
            </Button>
          ) : (
            <Button variant="outline" onClick={() => statusMutation.mutate("archived")} disabled={statusMutation.isPending}>
              Archive
            </Button>
          )}
          <Button variant="destructive" onClick={() => setDeleteOpen(true)}>
            Delete
          </Button>
        </PageHeader>
      </div>

      {student.current_goal || student.interests ? (
        <div className="grid gap-4 sm:grid-cols-2">
          {student.current_goal ? (
            <div className="rounded-lg bg-card p-5 shadow-sm">
              <p className="text-sm text-muted-foreground">Current goal</p>
              <p className="mt-1 text-[15px] text-foreground">{student.current_goal}</p>
            </div>
          ) : null}
          {student.interests ? (
            <div className="rounded-lg bg-card p-5 shadow-sm">
              <p className="text-sm text-muted-foreground">Interests</p>
              <p className="mt-1 text-[15px] text-foreground">{student.interests}</p>
            </div>
          ) : null}
        </div>
      ) : null}

      <DebatesCard debates={data.debates} />
      <ObservationsCard
        observations={data.observations}
        studentId={id}
        refresh={refresh}
      />
      <FeedbackCard
        feedback={data.feedback}
        studentId={id}
        refresh={refresh}
      />
      <ReflectionsCard reflections={data.reflections} refresh={refresh} />

      {/* Edit details */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit details</DialogTitle>
          </DialogHeader>
          <div className="mt-2">
            <Label className="mb-1.5 block text-sm">Name</Label>
            <Input value={editName} onChange={(e) => setEditName(e.target.value)} />
          </div>
          <div className="mt-3">
            <Label className="mb-1.5 block text-sm">Year group</Label>
            <Select value={editYear} onValueChange={setEditYear}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {YEAR_GROUPS.map((y) => (
                  <SelectItem key={y} value={y}>
                    {y}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setEditOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => updateMutation.mutate()} disabled={updateMutation.isPending || !editName.trim()}>
              {updateMutation.isPending ? "Saving…" : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={deleteOpen}
        title={`Delete ${student.display_name}?`}
        description="This permanently removes the student, their debates, feedback and reflections. This cannot be undone."
        confirmLabel="Delete student"
        requireText={student.display_name}
        onConfirm={() => deleteMutation.mutateAsync()}
        onOpenChange={(open) => {
          if (!open) setDeleteOpen(false);
        }}
      />
    </div>
  );
}

function DebatesCard({ debates }: { debates: Detail["debates"] }) {
  return (
    <Card title="Debates">
      {debates.length === 0 ? (
        <EmptyState title="No debates yet" message="When this student takes part in a debate, it will appear here." />
      ) : (
        <ul className="divide-y divide-border">
          {debates.map((d, i) => {
            const session = firstOf<SessionInfo>(d.debate_sessions as SessionInfo | SessionInfo[] | null);
            if (!session) return null;
            return (
              <li key={i} className="py-3 first:pt-0 last:pb-0">
                <p className="font-medium text-foreground">{session.motion}</p>
                <p className="mt-0.5 text-[13px] text-muted-foreground">
                  {formatDate(session.debate_date)}
                  {session.format ? ` · ${session.format}` : ""}
                  {d.role ? ` · Spoke as ${d.role}` : ""}
                </p>
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}

function ObservationsCard({
  observations,
  studentId,
  refresh,
}: {
  observations: Detail["observations"];
  studentId: string;
  refresh: () => void;
}) {
  const addFn = useServerFn(addObservation);
  const deleteFn = useServerFn(deleteObservation);
  const [open, setOpen] = React.useState(false);
  const [observedOn, setObservedOn] = React.useState(() => new Date().toISOString().slice(0, 10));
  const [skill, setSkill] = React.useState("");
  const [rating, setRating] = React.useState("");
  const [note, setNote] = React.useState("");

  const addMutation = useMutation({
    mutationFn: () =>
      addFn({
        data: {
          studentId,
          observedOn,
          skill,
          rating: rating ? Number(rating) : null,
          ...(note ? { note } : {}),
        },
      }),
    onSuccess: () => {
      setOpen(false);
      setSkill("");
      setRating("");
      setNote("");
      toast.success("Observation saved.");
      refresh();
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  const deleteMutation = useMutation({
    mutationFn: (observationId: string) => deleteFn({ data: { observationId } }),
    onSuccess: () => refresh(),
    onError: (err) => toast.error(errorMessage(err)),
  });

  return (
    <Card
      title="Skill observations"
      action={
        <Button variant="outline" size="sm" onClick={() => setOpen(true)}>
          Add observation
        </Button>
      }
    >
      {observations.length === 0 ? (
        <EmptyState
          title="Not assessed yet"
          message="Record what you notice in debates or practice — one skill at a time."
        />
      ) : (
        <ul className="divide-y divide-border">
          {(observations as Array<{ id: string; observed_on: string; skill: string; rating: number | null; note: string | null }>).map(
            (o) => (
              <li key={o.id} className="flex items-start justify-between gap-3 py-3 first:pt-0 last:pb-0">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone="teal">{o.skill}</Badge>
                    {o.rating ? <span className="text-[13px] text-muted-foreground">Rated {o.rating}/5</span> : null}
                  </div>
                  <p className="mt-1 text-[13px] text-muted-foreground">{formatDate(o.observed_on)}</p>
                  {o.note ? <p className="mt-1 text-[15px] text-foreground">{o.note}</p> : null}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-destructive"
                  onClick={() => deleteMutation.mutate(o.id)}
                  aria-label="Delete observation"
                >
                  Delete
                </Button>
              </li>
            ),
          )}
        </ul>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add observation</DialogTitle>
          </DialogHeader>
          <div className="mt-2 grid gap-3 sm:grid-cols-2">
            <div>
              <Label className="mb-1.5 block text-sm">Date</Label>
              <Input type="date" value={observedOn} onChange={(e) => setObservedOn(e.target.value)} />
            </div>
            <div>
              <Label className="mb-1.5 block text-sm">Skill</Label>
              <Select value={skill} onValueChange={setSkill}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a skill" />
                </SelectTrigger>
                <SelectContent>
                  {SKILL_OPTIONS.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1.5 block text-sm">Rating (optional)</Label>
              <Select value={rating} onValueChange={setRating}>
                <SelectTrigger>
                  <SelectValue placeholder="No rating" />
                </SelectTrigger>
                <SelectContent>
                  {["1", "2", "3", "4", "5"].map((r) => (
                    <SelectItem key={r} value={r}>
                      {r} / 5
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-3">
            <Label className="mb-1.5 block text-sm">Note (optional)</Label>
            <Textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3} />
          </div>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => addMutation.mutate()} disabled={addMutation.isPending || !skill || !observedOn}>
              {addMutation.isPending ? "Saving…" : "Save observation"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function FeedbackCard({
  feedback,
  studentId,
  refresh,
}: {
  feedback: Detail["feedback"];
  studentId: string;
  refresh: () => void;
}) {
  const addFn = useServerFn(addFeedback);
  const deleteFn = useServerFn(deleteFeedback);
  const [body, setBody] = React.useState("");
  const [skill, setSkill] = React.useState("");

  const addMutation = useMutation({
    mutationFn: () => addFn({ data: { studentId, body, ...(skill ? { skill } : {}) } }),
    onSuccess: () => {
      setBody("");
      setSkill("");
      toast.success("Feedback saved.");
      refresh();
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  const deleteMutation = useMutation({
    mutationFn: (feedbackId: string) => deleteFn({ data: { feedbackId } }),
    onSuccess: () => refresh(),
    onError: (err) => toast.error(errorMessage(err)),
  });

  return (
    <Card title="Feedback">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          addMutation.mutate();
        }}
      >
        <Textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          rows={3}
          placeholder="Write feedback for this student…"
        />
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <Select value={skill} onValueChange={setSkill}>
            <SelectTrigger className="w-56">
              <SelectValue placeholder="Skill (optional)" />
            </SelectTrigger>
            <SelectContent>
              {SKILL_OPTIONS.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button type="submit" disabled={addMutation.isPending || !body.trim()}>
            {addMutation.isPending ? "Saving…" : "Add feedback"}
          </Button>
        </div>
      </form>

      {feedback.length === 0 ? (
        <p className="mt-4 text-sm text-muted-foreground">No feedback yet.</p>
      ) : (
        <ul className="mt-4 divide-y divide-border">
          {(feedback as unknown as Array<{
            id: string;
            body: string;
            skill: string | null;
            created_at: string;
            author_name?: string | null;
          }>).map((f) => (
            <li key={f.id} className="flex items-start justify-between gap-3 py-3 first:pt-3">
              <div>
                <p className="text-[15px] text-foreground">{f.body}</p>
                <p className="mt-1 text-[13px] text-muted-foreground">
                  {f.author_name || "Mentor"}
                  {f.skill ? ` · ${f.skill}` : ""} · {formatDate(f.created_at)}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-destructive"
                onClick={() => deleteMutation.mutate(f.id)}
                aria-label="Delete feedback"
              >
                Delete
              </Button>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function ReflectionsCard({
  reflections,
  refresh,
}: {
  reflections: Detail["reflections"];
  refresh: () => void;
}) {
  const respondFn = useServerFn(respondToReflection);
  const [replyTo, setReplyTo] = React.useState<string | null>(null);
  const [reply, setReply] = React.useState("");

  const respondMutation = useMutation({
    mutationFn: (reflectionId: string) => respondFn({ data: { reflectionId, response: reply } }),
    onSuccess: () => {
      setReplyTo(null);
      setReply("");
      toast.success("Response sent.");
      refresh();
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  return (
    <Card title="Reflections">
      {reflections.length === 0 ? (
        <EmptyState
          title="No reflections yet"
          message="When this student writes a reflection after a debate, you can respond to it here."
        />
      ) : (
        <ul className="divide-y divide-border">
          {(reflections as Array<{
            id: string;
            body: string;
            created_at: string;
            response: string | null;
            responded_at: string | null;
          }>).map((r) => (
            <li key={r.id} className="py-3 first:pt-0 last:pb-0">
              <p className="text-[15px] text-foreground">{r.body}</p>
              <p className="mt-1 text-[13px] text-muted-foreground">{formatDate(r.created_at)}</p>
              {r.response ? (
                <div className="mt-2 rounded-md bg-muted px-3 py-2">
                  <p className="text-[15px] text-foreground">{r.response}</p>
                  <p className="mt-1 text-[13px] text-muted-foreground">
                    Your response · {formatDate(r.responded_at)}
                  </p>
                </div>
              ) : replyTo === r.id ? (
                <div className="mt-2">
                  <Textarea
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    rows={2}
                    placeholder="Write your response…"
                  />
                  <div className="mt-2 flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => respondMutation.mutate(r.id)}
                      disabled={respondMutation.isPending || !reply.trim()}
                    >
                      {respondMutation.isPending ? "Sending…" : "Send"}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setReplyTo(null);
                        setReply("");
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-2"
                  onClick={() => {
                    setReplyTo(r.id);
                    setReply("");
                  }}
                >
                  Respond
                </Button>
              )}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
