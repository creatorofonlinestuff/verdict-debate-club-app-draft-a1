import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell, Field, errorMessage } from "@/components/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset password — Verdict Support" },
      { name: "description", content: "Reset your Verdict Support password." },
      { property: "og:title", content: "Reset password — Verdict Support" },
      { property: "og:description", content: "Reset your Verdict Support password." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [mode, setMode] = React.useState<"request" | "set">("request");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [sent, setSent] = React.useState(false);

  React.useEffect(() => {
    if (window.location.hash.includes("type=recovery")) setMode("set");
  }, []);

  async function handleRequest(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { error: err } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (err) throw new Error(err.message);
      setSent(true);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function handleSet(e: React.FormEvent) {
    e.preventDefault();
    if (password !== confirm) {
      setError("The two passwords don't match.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const { error: err } = await supabase.auth.updateUser({ password });
      if (err) throw new Error(err.message);
      // Route by role once the password is set.
      const {
        data: { user },
      } = await supabase.auth.getUser();
      const { data: roleRow } = user
        ? await supabase.from("user_roles").select("role").eq("user_id", user.id).limit(1).maybeSingle()
        : { data: null };
      await navigate({ to: roleRow?.role === "mentor" ? "/mentor" : "/student" });
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  if (mode === "set") {
    return (
      <AuthShell
        title="Choose a new password"
        subtitle="Pick something you'll remember — at least 8 characters."
        footer={
          <Link to="/" className="hover:text-foreground">
            Back to home
          </Link>
        }
      >
        <form onSubmit={handleSet}>
          <Field label="New password">
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
              required
            />
          </Field>
          <Field label="Confirm new password">
            <Input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              autoComplete="new-password"
              required
            />
          </Field>
          {error ? <p className="mb-4 text-sm text-destructive">{error}</p> : null}
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Saving…" : "Save new password"}
          </Button>
        </form>
      </AuthShell>
    );
  }

  return (
    <AuthShell
      title="Forgot your password?"
      subtitle="Enter your email and we'll send you a link to choose a new password."
      footer={
        <Link to="/" className="hover:text-foreground">
          Back to home
        </Link>
      }
    >
      {sent ? (
        <p className="text-[15px] text-foreground">
          Check your inbox — we've sent a reset link. It may take a minute to arrive.
        </p>
      ) : (
        <form onSubmit={handleRequest}>
          <Field label="Email">
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              required
            />
          </Field>
          {error ? <p className="mb-4 text-sm text-destructive">{error}</p> : null}
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Sending…" : "Send reset link"}
          </Button>
        </form>
      )}
    </AuthShell>
  );
}
