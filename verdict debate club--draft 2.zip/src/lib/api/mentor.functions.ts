import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { generateNumericCode, sha256Hex } from "./crypto";

type Ctx = { supabase: SupabaseClient<Database>; userId: string };

const INVITE_EXPIRY_DAYS = 7;

type ClubInfo = { clubId: string; clubName: string; isOwner: boolean };

async function mentorClub(context: Ctx): Promise<ClubInfo> {
  const { data, error } = await context.supabase
    .from("user_roles")
    .select("club_id, is_owner, clubs(name)")
    .eq("user_id", context.userId)
    .eq("role", "mentor")
    .limit(1)
    .maybeSingle();
  if (error || !data) throw new Error("Mentor access is required for this action.");
  return {
    clubId: data.club_id as string,
    clubName: (data.clubs as unknown as { name: string } | null)?.name ?? "",
    isOwner: !!data.is_owner,
  };
}

async function createStudentInvitation(clubId: string, studentId: string, mentorId: string) {
  const code = generateNumericCode();
  const codeHash = await sha256Hex(code);
  const expiresAt = new Date(Date.now() + INVITE_EXPIRY_DAYS * 24 * 3600 * 1000).toISOString();
  const { error } = await supabaseAdminInsert("invitations", {
    student_id: studentId,
    club_id: clubId,
    code_hash: codeHash,
    expires_at: expiresAt,
    created_by: mentorId,
  });
  if (error) throw new Error("We couldn't create the invitation code.");
  return { code, expiresAt };
}

async function supabaseAdminInsert(
  table: string,
  values: Record<string, unknown>,
): Promise<{ error: { message: string } | null }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const res = await (supabaseAdmin as unknown as {
    from: (t: string) => { insert: (v: Record<string, unknown>) => Promise<{ error: { message: string } | null }> };
  }).from(table).insert(values);
  return res;
}

/* ---------------- Dashboard ---------------- */

export const getDashboard = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const sb = context.supabase;
    const today = new Date().toISOString().slice(0, 10);
    const [students, awaiting, upcoming] = await Promise.all([
      sb.from("students").select("id, joined_user_id, status").eq("club_id", club.clubId),
      sb
        .from("reflections")
        .select("id", { count: "exact", head: true })
        .eq("club_id", club.clubId)
        .is("responded_at", null),
      sb
        .from("debate_sessions")
        .select("id, motion, debate_date, format")
        .eq("club_id", club.clubId)
        .gte("debate_date", today)
        .order("debate_date", { ascending: true })
        .limit(5),
    ]);
    const allStudents = (students.data ?? []) as Array<{
      id: string;
      joined_user_id: string | null;
      status: string;
    }>;
    return {
      clubName: club.clubName,
      activeStudents: allStudents.filter((s) => s.status === "active").length,
      unclaimedInvitations: allStudents.filter((s) => !s.joined_user_id && s.status === "active").length,
      awaitingFeedback: awaiting.count ?? 0,
      upcoming: (upcoming.data ?? []) as Array<{
        id: string;
        motion: string;
        debate_date: string;
        format: string | null;
      }>,
    };
  });

/* ---------------- Students ---------------- */

export type StudentRow = {
  id: string;
  display_name: string;
  year_group: string;
  status: string;
  joined_user_id: string | null;
  current_goal: string | null;
  interests: string | null;
  created_at: string;
  has_active_invite: boolean;
  last_debate_date: string | null;
};

export const listStudents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const sb = context.supabase;
    const [students, invites, participations] = await Promise.all([
      sb.from("students").select("*").eq("club_id", club.clubId).order("display_name"),
      sb
        .from("invitations")
        .select("student_id")
        .eq("club_id", club.clubId)
        .is("used_at", null)
        .is("revoked_at", null)
        .gt("expires_at", new Date().toISOString()),
      sb
        .from("debate_participants")
        .select("student_id, debate_sessions(debate_date)")
        .in(
          "debate_id",
          (await sb.from("debate_sessions").select("id").eq("club_id", club.clubId)).data?.map((d) => d.id) ?? [
            "00000000-0000-0000-0000-000000000000",
          ],
        ),
    ]);
    const activeInviteStudents = new Set(
      ((invites.data ?? []) as Array<{ student_id: string }>).map((i) => i.student_id),
    );
    const lastDebate = new Map<string, string>();
    for (const p of (participations.data ?? []) as Array<{
      student_id: string;
      debate_sessions: { debate_date: string } | { debate_date: string }[] | null;
    }>) {
      const row = Array.isArray(p.debate_sessions) ? p.debate_sessions[0] : p.debate_sessions;
      const date = row?.debate_date;
      if (!date) continue;
      const prev = lastDebate.get(p.student_id);
      if (!prev || date > prev) lastDebate.set(p.student_id, date);
    }
    return ((students.data ?? []) as Array<Omit<StudentRow, "has_active_invite" | "last_debate_date">>).map(
      (s) => ({
        ...s,
        has_active_invite: activeInviteStudents.has(s.id),
        last_debate_date: lastDebate.get(s.id) ?? null,
      }),
    ) as StudentRow[];
  });

export const addStudent = createServerFn({ method: "POST" })
  .inputValidator((input: { displayName: string; yearGroup: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { displayName: string; yearGroup: string }; context: Ctx }) => {
    const club = await mentorClub(context);
    const displayName = data.displayName.trim();
    const yearGroup = data.yearGroup.trim();
    if (!displayName) throw new Error("Please enter the student's name.");
    if (!yearGroup) throw new Error("Please choose a year group.");
    const { data: student, error } = await context.supabase
      .from("students")
      .insert({ club_id: club.clubId, display_name: displayName, year_group: yearGroup, created_by: context.userId })
      .select("*")
      .single();
    if (error || !student) throw new Error("We couldn't add the student.");
    const invite = await createStudentInvitation(club.clubId, student.id, context.userId);
    return { student, code: invite.code, expiresAt: invite.expiresAt };
  });

export const regenerateInvitation = createServerFn({ method: "POST" })
  .inputValidator((input: { studentId: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { studentId: string }; context: Ctx }) => {
    const club = await mentorClub(context);
    const { data: student } = await context.supabase
      .from("students")
      .select("id, joined_user_id")
      .eq("id", data.studentId)
      .eq("club_id", club.clubId)
      .maybeSingle();
    if (!student) throw new Error("Student not found in your club.");
    if (student.joined_user_id) throw new Error("This student has already joined.");
    await context.supabase
      .from("invitations")
      .update({ revoked_at: new Date().toISOString() })
      .eq("student_id", data.studentId)
      .is("used_at", null)
      .is("revoked_at", null);
    const invite = await createStudentInvitation(club.clubId, data.studentId, context.userId);
    return invite;
  });

export const revokeInvitation = createServerFn({ method: "POST" })
  .inputValidator((input: { studentId: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { studentId: string }; context: Ctx }) => {
    await mentorClub(context);
    const { error } = await context.supabase
      .from("invitations")
      .update({ revoked_at: new Date().toISOString() })
      .eq("student_id", data.studentId)
      .is("used_at", null)
      .is("revoked_at", null);
    if (error) throw new Error("We couldn't revoke the code.");
    return { ok: true as const };
  });

export const updateStudent = createServerFn({ method: "POST" })
  .inputValidator((input: { studentId: string; displayName?: string; yearGroup?: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { studentId: string; displayName?: string; yearGroup?: string }; context: Ctx }) => {
    await mentorClub(context);
    const patch: { display_name?: string; year_group?: string } = {};
    if (data.displayName?.trim()) patch['display_name'] = data.displayName.trim();
    if (data.yearGroup?.trim()) patch['year_group'] = data.yearGroup.trim();
    if (!Object.keys(patch).length) return { ok: true as const };
    const { error } = await context.supabase.from("students").update(patch).eq("id", data.studentId);
    if (error) throw new Error("We couldn't update the student.");
    return { ok: true as const };
  });

export const setStudentStatus = createServerFn({ method: "POST" })
  .inputValidator((input: { studentId: string; status: "active" | "archived" }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { studentId: string; status: "active" | "archived" }; context: Ctx }) => {
    await mentorClub(context);
    const { error } = await context.supabase.from("students").update({ status: data.status }).eq("id", data.studentId);
    if (error) throw new Error("We couldn't update the student.");
    return { ok: true as const };
  });

export const deleteStudent = createServerFn({ method: "POST" })
  .inputValidator((input: { studentId: string; confirmName: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { studentId: string; confirmName: string }; context: Ctx }) => {
    await mentorClub(context);
    const { data: student } = await context.supabase
      .from("students")
      .select("display_name")
      .eq("id", data.studentId)
      .maybeSingle();
    if (!student) throw new Error("Student not found.");
    if (data.confirmName.trim().toLowerCase() !== student["display_name"].toLowerCase()) {
      throw new Error("The name you typed doesn't match.");
    }
    const { error } = await context.supabase.from("students").delete().eq("id", data.studentId);
    if (error) throw new Error("We couldn't delete the student.");
    return { ok: true as const };
  });

export const getStudentDetail = createServerFn({ method: "GET" })
  .inputValidator((input: { studentId: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { studentId: string }; context: Ctx }) => {
    const club = await mentorClub(context);
    const sb = context.supabase;
    const { data: student } = await sb
      .from("students")
      .select("*")
      .eq("id", data.studentId)
      .eq("club_id", club.clubId)
      .maybeSingle();
    if (!student) throw new Error("Student not found in your club.");
    const [feedback, participations, observations, reflections, assignments, invite] = await Promise.all([
      sb
        .from("feedback")
        .select("*")
        .eq("student_id", data.studentId)
        .order("created_at", { ascending: false }),
      sb
        .from("debate_participants")
        .select("role, debate_sessions(id, motion, debate_date, format)")
        .eq("student_id", data.studentId)
        .order("created_at", { ascending: false }),
      sb.from("skill_observations").select("*").eq("student_id", data.studentId).order("observed_on", { ascending: false }),
      sb.from("reflections").select("*").eq("student_id", data.studentId).order("created_at", { ascending: false }),
      sb
        .from("motion_assignments")
        .select("*, motions(text, category)")
        .eq("student_id", data.studentId)
        .order("assigned_at", { ascending: false }),
      sb
        .from("invitations")
        .select("expires_at")
        .eq("student_id", data.studentId)
        .is("used_at", null)
        .is("revoked_at", null)
        .gt("expires_at", new Date().toISOString())
        .maybeSingle(),
    ]);
    const authorIds = [
      ...new Set(
        ((feedback.data ?? []) as Array<{ author_id: string | null }>)
          .map((f) => f.author_id)
          .filter((a): a is string => !!a),
      ),
    ];
    const authorNames = new Map<string, string>();
    if (authorIds.length) {
      const { data: authors } = await sb.from("profiles").select("id, display_name").in("id", authorIds);
      for (const a of (authors ?? []) as Array<{ id: string; display_name: string }>) {
        authorNames.set(a.id, a.display_name);
      }
    }
    return {
      student,
      feedback: ((feedback.data ?? []) as Array<{ author_id: string | null }>).map((f) => ({
        ...f,
        author_name: f.author_id ? (authorNames.get(f.author_id) ?? "") : "",
      })),
      debates: (participations.data ?? []) as Array<{
        role: string | null;
        debate_sessions: { id: string; motion: string; debate_date: string; format: string | null } | { id: string; motion: string; debate_date: string; format: string | null }[] | null;
      }>,
      observations: observations.data ?? [],
      reflections: reflections.data ?? [],
      assignments: assignments.data ?? [],
      activeInviteExpiresAt: (invite.data as { expires_at: string } | null)?.expires_at ?? null,
    };
  });

/* ---------------- Debates ---------------- */

export const listDebates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const sb = context.supabase;
    const [debates, participants] = await Promise.all([
      sb.from("debate_sessions").select("*").eq("club_id", club.clubId).order("debate_date", { ascending: false }),
      sb.from("debate_participants").select("debate_id, role, students(display_name)"),
    ]);
    const byDebate = new Map<string, Array<{ name: string; role: string | null }>>();
    for (const p of (participants.data ?? []) as Array<{
      debate_id: string;
      role: string | null;
      students: { display_name: string } | { display_name: string }[] | null;
    }>) {
      const row = Array.isArray(p.students) ? p.students[0] : p.students;
      if (!row) continue;
      const list = byDebate.get(p.debate_id) ?? [];
      list.push({ name: row.display_name, role: p.role });
      byDebate.set(p.debate_id, list);
    }
    return (debates.data ?? []).map((d) => ({ ...d, participants: byDebate.get(d.id) ?? [] }));
  });

export const createDebate = createServerFn({ method: "POST" })
  .inputValidator(
    (input: {
      motion: string;
      debateDate: string;
      format?: string;
      notes?: string;
      participants: Array<{ studentId: string; role?: string }>;
    }) => input,
  )
  .middleware([requireSupabaseAuth])
  .handler(
    async ({
      data,
      context,
    }: {
      data: {
        motion: string;
        debateDate: string;
        format?: string;
        notes?: string;
        participants: Array<{ studentId: string; role?: string }>;
      };
      context: Ctx;
    }) => {
      const club = await mentorClub(context);
      if (!data.motion.trim()) throw new Error("Please enter the motion.");
      if (!data.debateDate) throw new Error("Please choose the debate date.");
      const { data: debate, error } = await context.supabase
        .from("debate_sessions")
        .insert({
          club_id: club.clubId,
          motion: data.motion.trim(),
          debate_date: data.debateDate,
          format: data.format?.trim() || null,
          notes: data.notes?.trim() || null,
          created_by: context.userId,
        })
        .select("id")
        .single();
      if (error || !debate) throw new Error("We couldn't create the debate.");
      if (data.participants.length) {
        const { error: pErr } = await context.supabase.from("debate_participants").insert(
          data.participants.map((p) => ({
            debate_id: debate.id,
            student_id: p.studentId,
            role: p.role?.trim() || null,
          })),
        );
        if (pErr) throw new Error("We couldn't save the participants.");
      }
      return { ok: true as const };
    },
  );

export const updateDebate = createServerFn({ method: "POST" })
  .inputValidator(
    (input: {
      debateId: string;
      motion?: string;
      debateDate?: string;
      format?: string;
      notes?: string;
      participants?: Array<{ studentId: string; role?: string }>;
    }) => input,
  )
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { debateId: string; motion?: string; debateDate?: string; format?: string; notes?: string; participants?: Array<{ studentId: string; role?: string }> }; context: Ctx }) => {
    await mentorClub(context);
    const patch: { motion?: string; debate_date?: string; format?: string | null; notes?: string | null } = {};
    if (data.motion?.trim()) patch['motion'] = data.motion.trim();
    if (data.debateDate) patch['debate_date'] = data.debateDate;
    if (data.format !== undefined) patch['format'] = data.format?.trim() || null;
    if (data.notes !== undefined) patch['notes'] = data.notes?.trim() || null;
    if (Object.keys(patch).length) {
      const { error } = await context.supabase.from("debate_sessions").update(patch).eq("id", data.debateId);
      if (error) throw new Error("We couldn't update the debate.");
    }
    if (data.participants) {
      await context.supabase.from("debate_participants").delete().eq("debate_id", data.debateId);
      if (data.participants.length) {
        const { error } = await context.supabase.from("debate_participants").insert(
          data.participants.map((p) => ({
            debate_id: data.debateId,
            student_id: p.studentId,
            role: p.role?.trim() || null,
          })),
        );
        if (error) throw new Error("We couldn't save the participants.");
      }
    }
    return { ok: true as const };
  });

export const deleteDebate = createServerFn({ method: "POST" })
  .inputValidator((input: { debateId: string; confirmMotion: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { debateId: string; confirmMotion: string }; context: Ctx }) => {
    await mentorClub(context);
    const { data: debate } = await context.supabase
      .from("debate_sessions")
      .select("motion")
      .eq("id", data.debateId)
      .maybeSingle();
    if (!debate) throw new Error("Debate not found.");
    if (data.confirmMotion.trim().toLowerCase() !== debate["motion"].toLowerCase()) {
      throw new Error("The motion you typed doesn't match.");
    }
    const { error } = await context.supabase.from("debate_sessions").delete().eq("id", data.debateId);
    if (error) throw new Error("We couldn't delete the debate.");
    return { ok: true as const };
  });

/* ---------------- Observations & feedback ---------------- */

export const addObservation = createServerFn({ method: "POST" })
  .inputValidator(
    (input: { studentId: string; observedOn: string; skill: string; rating?: number | null; note?: string; debateId?: string | null }) => input,
  )
  .middleware([requireSupabaseAuth])
  .handler(
    async ({
      data,
      context,
    }: {
      data: { studentId: string; observedOn: string; skill: string; rating?: number | null; note?: string; debateId?: string | null };
      context: Ctx;
    }) => {
      await mentorClub(context);
      if (!data.skill.trim()) throw new Error("Please choose a skill.");
      if (!data.observedOn) throw new Error("Please choose the date.");
      const { error } = await context.supabase.from("skill_observations").insert({
        student_id: data.studentId,
        debate_id: data.debateId || null,
        observed_on: data.observedOn,
        skill: data.skill.trim(),
        rating: data.rating ?? null,
        note: data.note?.trim() || null,
        observed_by: context.userId,
      });
      if (error) throw new Error("We couldn't save the observation.");
      return { ok: true as const };
    },
  );

export const deleteObservation = createServerFn({ method: "POST" })
  .inputValidator((input: { observationId: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { observationId: string }; context: Ctx }) => {
    await mentorClub(context);
    const { error } = await context.supabase.from("skill_observations").delete().eq("id", data.observationId);
    if (error) throw new Error("We couldn't delete the observation.");
    return { ok: true as const };
  });

export const addFeedback = createServerFn({ method: "POST" })
  .inputValidator(
    (input: { studentId: string; body: string; skill?: string; debateId?: string | null }) => input,
  )
  .middleware([requireSupabaseAuth])
  .handler(
    async ({
      data,
      context,
    }: {
      data: { studentId: string; body: string; skill?: string; debateId?: string | null };
      context: Ctx;
    }) => {
      const club = await mentorClub(context);
      if (!data.body.trim()) throw new Error("Please write the feedback.");
      const { error } = await context.supabase.from("feedback").insert({
        club_id: club.clubId,
        student_id: data.studentId,
        debate_id: data.debateId || null,
        skill: data.skill?.trim() || null,
        body: data.body.trim(),
        author_id: context.userId,
      });
      if (error) throw new Error("We couldn't save the feedback.");
      return { ok: true as const };
    },
  );

export const deleteFeedback = createServerFn({ method: "POST" })
  .inputValidator((input: { feedbackId: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { feedbackId: string }; context: Ctx }) => {
    await mentorClub(context);
    const { error } = await context.supabase.from("feedback").delete().eq("id", data.feedbackId);
    if (error) throw new Error("We couldn't delete the feedback.");
    return { ok: true as const };
  });

export const listFeedback = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const { data } = await context.supabase
      .from("feedback")
      .select("*, students(display_name)")
      .eq("club_id", club.clubId)
      .order("created_at", { ascending: false });
    const authorIds = [
      ...new Set(
        ((data ?? []) as Array<{ author_id: string | null }>)
          .map((f) => f.author_id)
          .filter((a): a is string => !!a),
      ),
    ];
    const authorNames = new Map<string, string>();
    if (authorIds.length) {
      const { data: authors } = await context.supabase
        .from("profiles")
        .select("id, display_name")
        .in("id", authorIds);
      for (const a of (authors ?? []) as Array<{ id: string; display_name: string }>) {
        authorNames.set(a.id, a.display_name);
      }
    }
    return ((data ?? []) as Array<{ author_id: string | null }>).map((f) => ({
      ...f,
      author_name: f.author_id ? (authorNames.get(f.author_id) ?? "") : "",
    }));
  });

export const listReflections = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const { data } = await context.supabase
      .from("reflections")
      .select("*, students(display_name)")
      .eq("club_id", club.clubId)
      .order("created_at", { ascending: false });
    return data ?? [];
  });

export const respondToReflection = createServerFn({ method: "POST" })
  .inputValidator((input: { reflectionId: string; response: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { reflectionId: string; response: string }; context: Ctx }) => {
    await mentorClub(context);
    if (!data.response.trim()) throw new Error("Please write a response.");
    const { error } = await context.supabase
      .from("reflections")
      .update({
        response: data.response.trim(),
        responded_by: context.userId,
        responded_at: new Date().toISOString(),
      })
      .eq("id", data.reflectionId);
    if (error) throw new Error("We couldn't save your response.");
    return { ok: true as const };
  });

/* ---------------- Motions ---------------- */

export const listMotions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const [motions, assignments] = await Promise.all([
      context.supabase.from("motions").select("*").eq("club_id", club.clubId).order("created_at", { ascending: false }),
      context.supabase
        .from("motion_assignments")
        .select("id, motion_id, student_id, due_date, status, students(display_name)"),
    ]);
    const byMotion = new Map<string, Array<{ id: string; student: string; due_date: string | null; status: string }>>();
    for (const a of (assignments.data ?? []) as Array<{
      id: string;
      motion_id: string;
      due_date: string | null;
      status: string;
      students: { display_name: string } | { display_name: string }[] | null;
    }>) {
      const row = Array.isArray(a.students) ? a.students[0] : a.students;
      if (!row) continue;
      const list = byMotion.get(a.motion_id) ?? [];
      list.push({ id: a.id, student: row.display_name, due_date: a.due_date, status: a.status });
      byMotion.set(a.motion_id, list);
    }
    return (motions.data ?? []).map((m) => ({ ...m, assignments: byMotion.get(m.id) ?? [] }));
  });

export const createMotion = createServerFn({ method: "POST" })
  .inputValidator((input: { text: string; category?: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { text: string; category?: string }; context: Ctx }) => {
    const club = await mentorClub(context);
    if (!data.text.trim()) throw new Error("Please enter the motion text.");
    const { error } = await context.supabase.from("motions").insert({
      club_id: club.clubId,
      text: data.text.trim(),
      category: data.category?.trim() || null,
      created_by: context.userId,
    });
    if (error) throw new Error("We couldn't save the motion.");
    return { ok: true as const };
  });

export const updateMotion = createServerFn({ method: "POST" })
  .inputValidator((input: { motionId: string; text?: string; category?: string | null }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { motionId: string; text?: string; category?: string | null }; context: Ctx }) => {
    await mentorClub(context);
    const patch: { text?: string; category?: string | null } = {};
    if (data.text?.trim()) patch['text'] = data.text.trim();
    if (data.category !== undefined) patch['category'] = data.category?.trim() || null;
    if (!Object.keys(patch).length) return { ok: true as const };
    const { error } = await context.supabase.from("motions").update(patch).eq("id", data.motionId);
    if (error) throw new Error("We couldn't update the motion.");
    return { ok: true as const };
  });

export const deleteMotion = createServerFn({ method: "POST" })
  .inputValidator((input: { motionId: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { motionId: string }; context: Ctx }) => {
    await mentorClub(context);
    const { error } = await context.supabase.from("motions").delete().eq("id", data.motionId);
    if (error) throw new Error("We couldn't delete the motion.");
    return { ok: true as const };
  });

export const assignMotion = createServerFn({ method: "POST" })
  .inputValidator((input: { motionId: string; studentIds: string[]; dueDate?: string | null }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { motionId: string; studentIds: string[]; dueDate?: string | null }; context: Ctx }) => {
    await mentorClub(context);
    if (!data.studentIds.length) throw new Error("Choose at least one student.");
    const { data: existing } = await context.supabase
      .from("motion_assignments")
      .select("student_id")
      .eq("motion_id", data.motionId);
    const already = new Set(((existing ?? []) as Array<{ student_id: string }>).map((e) => e.student_id));
    const toAdd = data.studentIds.filter((s) => !already.has(s));
    if (!toAdd.length) return { added: 0 as const };
    const { error } = await context.supabase.from("motion_assignments").insert(
      toAdd.map((studentId) => ({
        motion_id: data.motionId,
        student_id: studentId,
        due_date: data.dueDate || null,
        assigned_by: context.userId,
      })),
    );
    if (error) throw new Error("We couldn't assign the motion.");
    return { added: toAdd.length as number };
  });

export const unassignMotion = createServerFn({ method: "POST" })
  .inputValidator((input: { assignmentId: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { assignmentId: string }; context: Ctx }) => {
    await mentorClub(context);
    const { error } = await context.supabase.from("motion_assignments").delete().eq("id", data.assignmentId);
    if (error) throw new Error("We couldn't unassign the motion.");
    return { ok: true as const };
  });

/* ---------------- Co-mentors & settings ---------------- */

export const inviteMentor = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const code = generateNumericCode();
    const codeHash = await sha256Hex(code);
    const expiresAt = new Date(Date.now() + INVITE_EXPIRY_DAYS * 24 * 3600 * 1000).toISOString();
    const { error } = await context.supabase.from("mentor_invitations").insert({
      club_id: club.clubId,
      code_hash: codeHash,
      expires_at: expiresAt,
      created_by: context.userId,
    });
    if (error) throw new Error("We couldn't create the mentor invitation.");
    return { code, expiresAt };
  });

export const listMentorInvites = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const { data } = await context.supabase
      .from("mentor_invitations")
      .select("id, expires_at, used_at, revoked_at, created_at")
      .eq("club_id", club.clubId)
      .order("created_at", { ascending: false });
    return data ?? [];
  });

export const revokeMentorInvite = createServerFn({ method: "POST" })
  .inputValidator((input: { inviteId: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { inviteId: string }; context: Ctx }) => {
    await mentorClub(context);
    const { error } = await context.supabase
      .from("mentor_invitations")
      .update({ revoked_at: new Date().toISOString() })
      .eq("id", data.inviteId)
      .is("used_at", null);
    if (error) throw new Error("We couldn't revoke the invitation.");
    return { ok: true as const };
  });

export const listMentors = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const { data } = await context.supabase
      .from("user_roles")
      .select("id, user_id, is_owner, created_at, profiles(display_name, email)")
      .eq("club_id", club.clubId)
      .eq("role", "mentor");
    return data ?? [];
  });

export const rotateSetupCode = createServerFn({ method: "POST" })
  .inputValidator((input: { newCode: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { newCode: string }; context: Ctx }) => {
    const club = await mentorClub(context);
    if (!club.isOwner) throw new Error("Only the club owner can change the setup code.");
    const code = data.newCode.trim();
    if (code.length < 8) throw new Error("Use a setup code of at least 8 characters.");
    const codeHash = await sha256Hex(code);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("app_settings")
      .upsert({ id: "setup_code_hash", value: codeHash, updated_at: new Date().toISOString() });
    if (error) throw new Error("We couldn't update the setup code.");
    return { ok: true as const };
  });

export const deleteClub = createServerFn({ method: "POST" })
  .inputValidator((input: { confirmName: string }) => input)
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }: { data: { confirmName: string }; context: Ctx }) => {
    const club = await mentorClub(context);
    if (!club.isOwner) throw new Error("Only the club owner can delete the club.");
    if (data.confirmName.trim().toLowerCase() !== club.clubName.toLowerCase()) {
      throw new Error("The club name you typed doesn't match.");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("clubs").delete().eq("id", club.clubId);
    if (error) throw new Error("We couldn't delete the club.");
    return { ok: true as const };
  });

export const exportClubData = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const club = await mentorClub(context);
    const sb = context.supabase;
    const [students, debates, participants, observations, feedback, motions, assignments, reflections] =
      await Promise.all([
        sb.from("students").select("*").eq("club_id", club.clubId),
        sb.from("debate_sessions").select("*").eq("club_id", club.clubId),
        sb.from("debate_participants").select("*"),
        sb.from("skill_observations").select("*"),
        sb.from("feedback").select("*").eq("club_id", club.clubId),
        sb.from("motions").select("*").eq("club_id", club.clubId),
        sb.from("motion_assignments").select("*"),
        sb.from("reflections").select("*").eq("club_id", club.clubId),
      ]);
    const clubStudentIds = new Set(((students.data ?? []) as Array<{ id: string }>).map((s) => s.id));
    const clubDebateIds = new Set(((debates.data ?? []) as Array<{ id: string }>).map((d) => d.id));
    const clubMotionIds = new Set(((motions.data ?? []) as Array<{ id: string }>).map((m) => m.id));
    return {
      exportedAt: new Date().toISOString(),
      club: { name: club.clubName },
      students: students.data ?? [],
      debates: debates.data ?? [],
      participants: ((participants.data ?? []) as Array<{ debate_id: string; student_id: string }>).filter(
        (p) => clubDebateIds.has(p.debate_id) && clubStudentIds.has(p.student_id),
      ),
      observations: ((observations.data ?? []) as Array<{ student_id: string }>).filter((o) =>
        clubStudentIds.has(o.student_id),
      ),
      feedback: feedback.data ?? [],
      motions: motions.data ?? [],
      motionAssignments: ((assignments.data ?? []) as Array<{ motion_id: string; student_id: string }>).filter(
        (a) => clubMotionIds.has(a.motion_id) && clubStudentIds.has(a.student_id),
      ),
      reflections: reflections.data ?? [],
    };
  });
