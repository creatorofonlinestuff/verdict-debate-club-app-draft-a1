/**
 * Privileged provisioning logic. This module is ONLY ever imported dynamically
 * inside server-function handler bodies, so it never reaches the client bundle.
 */
import { sha256Hex, generateNumericCode } from "./crypto";

const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

export const INVITE_EXPIRY_DAYS = 7;
const MAX_ATTEMPTS_PER_WINDOW = 8;
const ATTEMPT_WINDOW_MINUTES = 15;

export function normaliseEmail(email: string): string {
  return email.trim().toLowerCase();
}

export function validateCredentials(email: string, password: string): string | null {
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Please enter a valid email address.";
  if (password.length < 8) return "Password must be at least 8 characters.";
  return null;
}

async function hashAndInsertAttempts(attemptKey: string, submitted: string, success: boolean) {
  await supabaseAdmin.from("redemption_attempts").insert({
    attempt_key: attemptKey,
    submitted_hash: await sha256Hex(submitted),
    success,
  });
}

async function assertNotRateLimited(attemptKey: string) {
  const since = new Date(Date.now() - ATTEMPT_WINDOW_MINUTES * 60_000).toISOString();
  const { count } = await supabaseAdmin
    .from("redemption_attempts")
    .select("id", { count: "exact", head: true })
    .eq("attempt_key", attemptKey)
    .eq("success", false)
    .gt("created_at", since);
  if ((count ?? 0) >= MAX_ATTEMPTS_PER_WINDOW) {
    throw new Error("Too many attempts. Please wait 15 minutes and try again.");
  }
}

/** Returns null when valid, otherwise a generic rejection message. */
function invitationRejection(row: {
  used_at: string | null;
  revoked_at: string | null;
  expires_at: string;
}): string | null {
  if (!row) return "This code isn't valid. Ask your mentor for a new one.";
  if (row.revoked_at || row.used_at || new Date(row.expires_at).getTime() < Date.now()) {
    return "This code isn't valid anymore. Ask your mentor for a new one.";
  }
  return null;
}

async function createAccount(email: string, password: string, displayName: string) {
  const { data, error } = await supabaseAdmin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { display_name: displayName },
  });
  if (error || !data.user) {
    const msg = error?.message ?? "";
    if (/already/i.test(msg)) {
      throw new Error("An account with this email already exists. Try signing in instead.");
    }
    throw new Error("We couldn't create the account. Please try again.");
  }
  return data.user;
}

async function cleanupUser(userId: string) {
  try {
    await supabaseAdmin.auth.admin.deleteUser(userId);
  } catch {
    // best effort
  }
}

export async function verifySetupCode(code: string): Promise<void> {
  const { data } = await supabaseAdmin
    .from("app_settings")
    .select("value")
    .eq("id", "setup_code_hash")
    .maybeSingle();
  if (!data || (await sha256Hex(code.trim())) !== data.value) {
    throw new Error("That setup code isn't valid.");
  }
}

async function insertProfile(userId: string, displayName: string, email: string) {
  const { error } = await supabaseAdmin
    .from("profiles")
    .insert({ id: userId, display_name: displayName, email });
  if (error) throw new Error("We couldn't finish setting up the profile.");
}

export async function setupFounder(input: {
  clubName: string;
  email: string;
  password: string;
  displayName: string;
}): Promise<{ ok: true }> {
  const user = await createAccount(input.email, input.password, input.displayName);
  try {
    await insertProfile(user.id, input.displayName, input.email);
    const { data: club, error: clubErr } = await supabaseAdmin
      .from("clubs")
      .insert({ name: input.clubName.trim(), created_by: user.id })
      .select("id")
      .single();
    if (clubErr || !club) throw new Error("We couldn't create the club.");
    const { error: roleErr } = await supabaseAdmin.from("user_roles").insert({
      user_id: user.id,
      role: "mentor",
      club_id: club.id,
      is_owner: true,
    });
    if (roleErr) throw new Error("We couldn't grant the mentor role.");
  } catch (err) {
    await cleanupUser(user.id);
    throw err;
  }
  return { ok: true };
}

export async function setupCoMentor(input: {
  inviteCode: string;
  email: string;
  password: string;
  displayName: string;
  attemptKey: string;
}): Promise<{ ok: true }> {
  await assertNotRateLimited(input.attemptKey);
  const hash = await sha256Hex(input.inviteCode.trim());
  const { data: invite } = await supabaseAdmin
    .from("mentor_invitations")
    .select("*")
    .eq("code_hash", hash)
    .maybeSingle();
  const rejection = invite
    ? invitationRejection(invite)
    : "This invitation code isn't valid. Ask a mentor for a new one.";
  if (rejection) {
    await hashAndInsertAttempts(input.attemptKey, input.inviteCode, false);
    throw new Error(rejection);
  }

  const user = await createAccount(input.email, input.password, input.displayName);
  try {
    await insertProfile(user.id, input.displayName, input.email);
    const { error: roleErr } = await supabaseAdmin.from("user_roles").insert({
      user_id: user.id,
      role: "mentor",
      club_id: invite!.club_id,
      is_owner: false,
    });
    if (roleErr) throw new Error("We couldn't grant the mentor role.");
    const { error: usedErr } = await supabaseAdmin
      .from("mentor_invitations")
      .update({ used_at: new Date().toISOString(), redeemed_by: user.id })
      .eq("id", invite!.id)
      .is("used_at", null);
    if (usedErr) throw new Error("This code was just used. Ask for a new invitation.");
  } catch (err) {
    await cleanupUser(user.id);
    throw err;
  }
  await hashAndInsertAttempts(input.attemptKey, input.inviteCode, true);
  return { ok: true };
}

export async function redeemStudentInvitation(input: {
  code: string;
  email: string;
  password: string;
  attemptKey: string;
}): Promise<{ ok: true }> {
  await assertNotRateLimited(input.attemptKey);
  const hash = await sha256Hex(input.code.trim());
  const { data: invite } = await supabaseAdmin
    .from("invitations")
    .select("*")
    .eq("code_hash", hash)
    .maybeSingle();
  const rejection = invite
    ? invitationRejection(invite)
    : "This code isn't valid. Check it with your mentor.";
  if (rejection) {
    await hashAndInsertAttempts(input.attemptKey, input.code, false);
    throw new Error(rejection);
  }

  const { data: studentRow } = await supabaseAdmin
    .from("students")
    .select("display_name")
    .eq("id", invite!.student_id)
    .maybeSingle();
  const displayName = studentRow?.display_name ?? "Student";
  const user = await createAccount(input.email, input.password, displayName);
  await insertProfile(user.id, displayName, input.email);

  try {
    const { error: roleErr } = await supabaseAdmin.from("user_roles").insert({
      user_id: user.id,
      role: "student",
      club_id: invite!.club_id,
      is_owner: false,
    });
    if (roleErr) throw new Error("We couldn't link this account to the club.");
    const { data: linked, error: linkErr } = await supabaseAdmin
      .from("students")
      .update({ joined_user_id: user.id })
      .eq("id", invite!.student_id)
      .is("joined_user_id", null)
      .select("id");
    if (linkErr || !linked || linked.length === 0) {
      throw new Error("This code has already been claimed. Ask your mentor for a new one.");
    }
    const { error: usedErr } = await supabaseAdmin
      .from("invitations")
      .update({ used_at: new Date().toISOString(), redeemed_by: user.id })
      .eq("id", invite!.id)
      .is("used_at", null);
    if (usedErr) throw new Error("This code was just claimed. Ask your mentor for a new one.");
  } catch (err) {
    await cleanupUser(user.id);
    throw err;
  }
  await hashAndInsertAttempts(input.attemptKey, input.code, true);
  return { ok: true };
}
