import { createServerFn, createMiddleware } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { sha256Hex } from "./crypto";
import { validateMentorSetupInput } from "../mentor-setup-validation";

type Ctx = { supabase: SupabaseClient<Database>; userId: string };

const ipMiddleware = createMiddleware().server(({ request, next }) =>
  next({ context: { ip: request.headers.get("x-forwarded-for") ?? "unknown" } }),
);

export const setupMentor = createServerFn({ method: "POST" })
  .inputValidator(
    (input: {
      mode: "founder" | "co-mentor";
      code?: string;
      clubName?: string;
      email: string;
      password: string;
      displayName: string;
    }) => validateMentorSetupInput(input),
  )
  .middleware([ipMiddleware])
  .handler(async ({ data, context }) => {
    const attemptKey = await sha256Hex(context.ip);
    const email = data.email.trim().toLowerCase();
    const { validateCredentials, setupFounder, setupCoMentor } = await import("./admin");
    const credError = validateCredentials(email, data.password);
    if (credError) throw new Error(credError);
    if (!data.displayName.trim()) throw new Error("Please enter your name.");
    if (data.mode === "founder") {
      const clubName = data.clubName?.trim();
      if (!clubName) throw new Error("Please enter a club name.");
      await setupFounder({
        clubName,
        email,
        password: data.password,
        displayName: data.displayName.trim(),
      });
    } else {
      const inviteCode = data.code?.trim();
      if (!inviteCode) throw new Error("Enter the invitation code from your club mentor.");
      await setupCoMentor({
        inviteCode,
        email,
        password: data.password,
        displayName: data.displayName.trim(),
        attemptKey,
      });
    }
    return { ok: true as const };
  });

export const redeemStudentInvitation = createServerFn({ method: "POST" })
  .inputValidator((input: { code: string; email: string; password: string }) => input)
  .middleware([ipMiddleware])
  .handler(async ({ data, context }) => {
    const attemptKey = await sha256Hex(context.ip);
    const email = data.email.trim().toLowerCase();
    const { validateCredentials, redeemStudentInvitation: redeem } = await import("./admin");
    const credError = validateCredentials(email, data.password);
    if (credError) throw new Error(credError);
    await redeem({ code: data.code, email, password: data.password, attemptKey });
    return { ok: true as const };
  });

export const getMyRole = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: Ctx }) => {
    const { data: roleRow } = await context.supabase
      .from("user_roles")
      .select("role, club_id, is_owner, clubs(name)")
      .eq("user_id", context.userId)
      .limit(1)
      .maybeSingle();
    if (!roleRow) return null;
    let displayName = "";
    if (roleRow.role === "student") {
      const { data: studentRow } = await context.supabase
        .from("students")
        .select("display_name")
        .eq("joined_user_id", context.userId)
        .maybeSingle();
      displayName = (studentRow?.display_name as string | undefined) ?? "";
    } else {
      const { data: profileRow } = await context.supabase
        .from("profiles")
        .select("display_name")
        .eq("id", context.userId)
        .maybeSingle();
      displayName = (profileRow?.display_name as string | undefined) ?? "";
    }
    return {
      role: roleRow.role as "mentor" | "student",
      clubId: roleRow.club_id as string,
      clubName: (roleRow.clubs as unknown as { name: string } | null)?.name ?? "",
      isOwner: !!roleRow.is_owner,
      displayName,
    };
  });
