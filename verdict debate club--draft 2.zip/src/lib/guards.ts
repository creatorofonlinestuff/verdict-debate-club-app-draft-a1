import { redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export type ViewerRole = {
  role: "mentor" | "student";
  clubId: string;
  clubName: string;
  isOwner: boolean;
  userId: string;
  displayName: string;
};

/** Client-side route guard. Call from a layout route whose ssr is false. */
export async function requireMentor(): Promise<ViewerRole> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw redirect({ to: "/mentor/login" as never });

  const { data: roleRow } = await supabase
    .from("user_roles")
    .select("role, club_id, is_owner, clubs(name)")
    .eq("user_id", user.id)
    .limit(1)
    .maybeSingle();

  if (!roleRow) {
    await supabase.auth.signOut();
    throw redirect({ to: "/mentor/login" as never });
  }

  const role = roleRow.role;
  if (role === "student") throw redirect({ to: "/student" as never });
  if (role !== "mentor") {
    await supabase.auth.signOut();
    throw redirect({ to: "/mentor/login" as never });
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("display_name")
    .eq("id", user.id)
    .maybeSingle();

  return {
    role: "mentor",
    clubId: roleRow.club_id as string,
    clubName: (roleRow.clubs as unknown as { name: string } | null)?.name ?? "",
    isOwner: !!roleRow.is_owner,
    userId: user.id,
    displayName: profile?.display_name ?? "",
  };
}

export async function requireStudent(): Promise<ViewerRole> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw redirect({ to: "/student/login" as never });

  const { data: roleRow } = await supabase
    .from("user_roles")
    .select("role, club_id, clubs(name)")
    .eq("user_id", user.id)
    .limit(1)
    .maybeSingle();

  if (!roleRow) {
    await supabase.auth.signOut();
    throw redirect({ to: "/student/login" as never });
  }

  const role = roleRow.role;
  if (role === "mentor") throw redirect({ to: "/mentor" as never });
  if (role !== "student") {
    await supabase.auth.signOut();
    throw redirect({ to: "/student/login" as never });
  }

  const { data: studentRow } = await supabase
    .from("students")
    .select("display_name")
    .eq("joined_user_id", user.id)
    .maybeSingle();

  return {
    role: "student",
    clubId: roleRow.club_id as string,
    clubName: (roleRow.clubs as unknown as { name: string } | null)?.name ?? "",
    isOwner: false,
    userId: user.id,
    displayName: (studentRow?.display_name as string | undefined) ?? "",
  };
}
