export type MentorSetupInput = {
  mode: "founder" | "co-mentor";
  code?: string;
  clubName?: string;
  email: string;
  password: string;
  displayName: string;
};

export function validateMentorSetupInput(input: MentorSetupInput): MentorSetupInput {
  if (input.mode === "founder" && !input.clubName?.trim()) {
    throw new Error("Please enter a club name.");
  }

  if (input.mode === "co-mentor" && !input.code?.trim()) {
    throw new Error("Enter the invitation code from your club mentor.");
  }

  return input;
}