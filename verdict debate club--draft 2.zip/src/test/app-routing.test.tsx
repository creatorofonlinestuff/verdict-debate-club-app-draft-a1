import { QueryClient } from "@tanstack/react-query";
import { createRouter, rootRouteId } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";

import { routeTree } from "@/routeTree.gen";

// Match routes without running loaders or rendering: loaders may need a server or
// network the test run lacks, and jsdom never loads the stylesheets React waits on.
describe("App routing", () => {
  it("matches a page for / instead of falling back to not found", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });

    const matches = router.matchRoutes("/");

    expect(matches.at(-1)?.routeId).not.toBe(rootRouteId);
  });

  it("keeps public sign-in and setup pages outside protected portal layouts", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });

    const routesFor = (path: string) => router.matchRoutes(path).map((match) => match.routeId);

    expect(routesFor("/mentor/login")).toContain("/mentor_/login");
    expect(routesFor("/mentor/login")).not.toContain("/mentor");
    expect(routesFor("/mentor/setup")).toContain("/mentor_/setup");
    expect(routesFor("/mentor/setup")).not.toContain("/mentor");
    expect(routesFor("/student/login")).toContain("/student_/login");
    expect(routesFor("/student/login")).not.toContain("/student");
    expect(routesFor("/mentor")).toContain("/mentor");
    expect(routesFor("/mentor")).toContain("/mentor/");
    expect(routesFor("/student")).toContain("/student");
    expect(routesFor("/student")).toContain("/student/");
    expect(routesFor("/mentor/students")).toContain("/mentor");
    expect(routesFor("/mentor/students")).toContain("/mentor/students");
    expect(routesFor("/join")).toContain("/join");
  });
});
