import { describe, expect, it } from "vitest";
import { validateMentorSetupInput } from "@/lib/mentor-setup-validation";

describe("mentor club setup", () => {
  it("allows a founder to create a club without a pre-issued setup code", () => {
    expect(() =>
      validateMentorSetupInput({
        mode: "founder",
        clubName: "Northside Debate Club",
        email: "mentor@example.com",
        password: "secure-password",
        displayName: "Avery",
      }),
    ).not.toThrow();
  });

  it("continues to require an invitation code for co-mentors", () => {
    expect(() =>
      validateMentorSetupInput({
        mode: "co-mentor",
        email: "mentor@example.com",
        password: "secure-password",
        displayName: "Avery",
      }),
    ).toThrow("Enter the invitation code from your club mentor.");
  });
});