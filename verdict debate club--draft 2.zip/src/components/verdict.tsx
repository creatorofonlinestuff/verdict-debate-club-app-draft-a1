import * as React from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export function PageHeader({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string | undefined;
  children?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 className="text-[30px] font-bold text-foreground">{title}</h1>
        {subtitle ? <p className="mt-1 text-[15px] text-muted-foreground">{subtitle}</p> : null}
      </div>
      {children ? <div className="flex flex-wrap gap-2">{children}</div> : null}
    </div>
  );
}

export function EmptyState({
  title,
  message,
  children,
}: {
  title: string;
  message: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border border-dashed border-border bg-card px-6 py-10 text-center">
      <h3 className="text-[17px] font-semibold text-foreground">{title}</h3>
      <p className="mx-auto mt-1 max-w-md text-[15px] text-muted-foreground">{message}</p>
      {children ? <div className="mt-4 flex justify-center gap-2">{children}</div> : null}
    </div>
  );
}

export function StatCard({ label, value, hint }: { label: string; value: string | number; hint?: string | undefined }) {
  return (
    <div className="rounded-lg bg-card p-5 shadow-sm">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-1 text-3xl font-bold text-foreground">{value}</p>
      {hint ? <p className="mt-1 text-[13px] text-muted-foreground">{hint}</p> : null}
    </div>
  );
}

export function Badge({
  children,
  tone = "neutral",
}: {
  children: React.ReactNode;
  tone?: "neutral" | "teal" | "orange" | "muted" | "danger";
}) {
  const tones: Record<string, string> = {
    neutral: "bg-secondary text-secondary-foreground",
    teal: "bg-teal text-teal-foreground",
    orange: "bg-accent text-accent-foreground",
    muted: "bg-muted text-muted-foreground",
    danger: "bg-destructive/10 text-destructive",
  };
  return (
    <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-[13px] font-medium", tones[tone])}>
      {children}
    </span>
  );
}

/** Confirmation dialog for destructive actions. Optionally requires typing a phrase. */
export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = "Confirm",
  requireText,
  onConfirm,
  onOpenChange,
  destructive = true,
}: {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  requireText?: string;
  onConfirm: () => unknown;
  onOpenChange: (open: boolean) => void;
  destructive?: boolean;
}) {
  const [typed, setTyped] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  React.useEffect(() => {
    if (!open) setTyped("");
  }, [open]);
  const blocked = !!requireText && typed.trim().toLowerCase() !== requireText.trim().toLowerCase();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        {requireText ? (
          <div className="mt-2">
            <label className="mb-1 block text-sm text-muted-foreground">
              Type <span className="font-semibold text-foreground">{requireText}</span> to confirm
            </label>
            <Input value={typed} onChange={(e) => setTyped(e.target.value)} />
          </div>
        ) : null}
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            variant={destructive ? "destructive" : "default"}
            disabled={blocked || busy}
            onClick={async () => {
              setBusy(true);
              try {
                await onConfirm();
                onOpenChange(false);
              } finally {
                setBusy(false);
              }
            }}
          >
            {busy ? "Working…" : confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function formatDate(value: string | null | undefined): string {
  if (!value) return "";
  const d = new Date(value.length <= 10 ? value + "T00:00:00" : value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

export const SKILL_OPTIONS = [
  "Argumentation",
  "Rebuttal",
  "Delivery",
  "Structure",
  "Evidence and analysis",
  "Teamwork",
];

export const DEBATE_FORMATS = [
  "British Parliamentary",
  "Asian Parliamentary",
  "Public Forum",
  "Free debate",
];

export const YEAR_GROUPS = [
  "Year 7",
  "Year 8",
  "Year 9",
  "Year 10",
  "Year 11",
  "Year 12",
  "Year 13",
  "Sixth form",
  "Other",
];
