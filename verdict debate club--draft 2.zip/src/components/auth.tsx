import * as React from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { formatDate } from "@/components/verdict";

export function errorMessage(err: unknown): string {
  if (err instanceof Error && err.message) return err.message;
  return "Something went wrong. Please try again.";
}

/** Centered card shell used by every public auth page. */
export function AuthShell({
  title,
  subtitle,
  children,
  footer,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background px-4 py-12">
      <Link to="/" className="text-[15px] font-bold tracking-tight text-foreground hover:opacity-80">
        Verdict Support
      </Link>
      <div className="mt-6 w-full max-w-md rounded-xl border border-border bg-card p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-foreground">{title}</h1>
        <p className="mt-1 text-[15px] text-muted-foreground">{subtitle}</p>
        <div className="mt-6">{children}</div>
      </div>
      {footer ? <div className="mt-5 text-center text-sm text-muted-foreground">{footer}</div> : null}
    </div>
  );
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mb-4">
      <Label className="mb-1.5 block text-sm">{label}</Label>
      {children}
      {hint ? <p className="mt-1 text-[13px] text-muted-foreground">{hint}</p> : null}
    </div>
  );
}

/** Shared sign-in form for both portals. Routes the user by their real role. */
export function SignInForm({ portal }: { portal: "mentor" | "student" }) {
  const navigate = useNavigate();
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      if (signInError) {
        throw new Error(
          /invalid/i.test(signInError.message)
            ? "Email or password is incorrect."
            : signInError.message,
        );
      }
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error("We couldn't confirm the sign-in. Please try again.");
      const { data: roleRow } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .limit(1)
        .maybeSingle();
      const role = (roleRow?.role as string | undefined) ?? null;

      if (role === "mentor") {
        await navigate({ to: "/mentor" });
        return;
      }
      if (role === "student") {
        if (portal === "mentor") {
          setError("This is a student account. Use the student sign-in instead.");
          await supabase.auth.signOut();
          return;
        }
        await navigate({ to: "/student" });
        return;
      }
      await supabase.auth.signOut();
      setError(
        portal === "mentor"
          ? "We couldn't find a mentor account for this email. Setting up a new club? Use 'Set up your club' below."
          : "We couldn't find this account in a club. Ask your mentor to check your invitation code.",
      );
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <Field label="Email">
        <Input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="email"
          required
        />
      </Field>
      <Field label="Password">
        <Input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
          required
        />
      </Field>
      {error ? <p className="mb-4 text-sm text-destructive">{error}</p> : null}
      <Button type="submit" className="w-full" disabled={busy}>
        {busy ? "Signing in…" : "Sign in"}
      </Button>
      <div className="mt-3 text-center text-sm text-muted-foreground">
        <Link to="/reset-password" className="hover:text-foreground">
          Forgot your password?
        </Link>
      </div>
    </form>
  );
}

/** Sign out: stop queries, clear cache, clear session, then leave the protected area. */
export function useSignOut(returnTo: "/mentor/login" | "/student/login") {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  return React.useCallback(async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    await navigate({ to: returnTo, replace: true });
  }, [navigate, queryClient, returnTo]);
}

/** Shows a freshly generated invitation code once — codes are never stored in readable form. */
export function CodeDialog({
  open,
  code,
  expiresAt,
  onOpenChange,
}: {
  open: boolean;
  code: string;
  expiresAt: string;
  onOpenChange: (open: boolean) => void;
}) {
  const [copied, setCopied] = React.useState(false);
  React.useEffect(() => {
    if (!open) setCopied(false);
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Invitation code</DialogTitle>
          <DialogDescription>
            Give this code to the student. It works once and expires on {formatDate(expiresAt)}.
            For security it can't be shown again — generate a new one if it's lost.
          </DialogDescription>
        </DialogHeader>
        <div className="my-2 flex items-center justify-center gap-3 rounded-lg bg-muted px-4 py-5">
          <span className="text-4xl font-bold tracking-[0.3em] text-foreground">{code}</span>
        </div>
        <p className="text-[13px] text-muted-foreground">
          The student joins from the home page under "Students — have a code?".
        </p>
        <DialogFooter className="mt-2">
          <Button
            variant="outline"
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(code);
                setCopied(true);
              } catch {
                setCopied(false);
              }
            }}
          >
            {copied ? "Copied" : "Copy code"}
          </Button>
          <Button onClick={() => onOpenChange(false)}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
