<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Debate club students grow into more skilled, confident debaters.

## Metric

Mentor feedback items read by their student each week
