# Verdict Support — build roadmap

## Done
- [x] Lovable Cloud enabled, email/password auth enabled
- [x] Database schema + RLS + founder code seed (migration 0000)
- [x] Server functions (auth provisioning, mentor ops, student ops, invitation redemption)
- [x] Portal chooser (/), mentor login/setup, student join + login, reset password
- [x] Mentor portal layout (nav, sign out, role guard) + dashboard
- [x] Mentor students: add student, invitation codes (generate/regenerate/revoke), archive/restore, typed-confirm delete
- [x] Student profile: debates, skill observations, feedback, reflections (respond)
- [x] Minimal student portal home (empty states)
- [x] Keep public mentor/student sign-in and mentor setup pages outside protected layouts to prevent redirect loops
- [x] Let founders create a club from scratch without a pre-issued setup code; keep co-mentor invites gated
- [x] Refresh the app palette with dark graphite, lime, teal, and coral accents

## In progress
- [x] Diagnose and fix the blank portal screen after signing in; verify the signed-in destination
- [ ] End-to-end verification (mentor setup, add student, join, record progress, access rules)
- [x] Fixed build errors and verified the portal chooser, mentor dashboard/student directory protected-route matching, code-join screen, and code-free club setup

## Open / waiting
- [ ] Mentor debates page (create/edit/delete debates with participants)
- [ ] Mentor feedback & reflections inbox pages
- [ ] Mentor motions library + assignments page
- [ ] Mentor settings (club name, co-mentor invites, rotate setup code, export data, delete club)
- [ ] Student portal: profile (goal/interests), reflection writing, progress, motions views
