<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Public portal sign-in and setup routes use trailing-underscore route files so they do not inherit protected portal layout guards; this prevents self-redirect loops while preserving public URLs.
- Founder club provisioning stays public and code-free, while co-mentor provisioning requires a verified invitation in the server function; this lets new clubs start without weakening role assignment.
- Founder setup input rules live in a small client/server-safe validator module so public forms and server functions share testable requirements.
