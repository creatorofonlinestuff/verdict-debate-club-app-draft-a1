import * as React from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import {
  queryOptions,
  useMutation,
  useQueryClient,
  useSuspenseQuery,
} from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  addStudent,
  deleteStudent,
  listStudents,
  regenerateInvitation,
  revokeInvitation,
  setStudentStatus,
  type StudentRow,
} from "@/lib/api/mentor.functions";
import { Badge, ConfirmDialog, EmptyState, PageHeader, YEAR_GROUPS, formatDate } from "@/components/verdict";
import { CodeDialog, errorMessage } from "@/components/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/mentor/students/")({
  loader: ({ context }) =>
    context.queryClient.ensureQueryData(
      queryOptions({ queryKey: ["mentor-students"], queryFn: () => listStudents() }),
    ),
  errorComponent: ({ error }) => (
    <div role="alert" className="text-destructive">
      {error instanceof Error ? error.message : "Couldn't load your students."}
    </div>
  ),
  component: StudentsPage,
});

type Status = "joined" | "invited" | "pending" | "archived";

function statusOf(s: StudentRow): Status {
  if (s.status === "archived") return "archived";
  if (s.joined_user_id) return "joined";
  if (s.has_active_invite) return "invited";
  return "pending";
}

function StatusBadge({ status }: { status: Status }) {
  switch (status) {
    case "joined":
      return <Badge tone="teal">Joined</Badge>;
    case "invited":
      return <Badge tone="orange">Code sent</Badge>;
    case "pending":
      return <Badge tone="muted">No active code</Badge>;
    case "archived":
      return <Badge tone="muted">Archived</Badge>;
  }
}

function StudentsPage() {
  const queryClient = useQueryClient();
  const { data: students } = useSuspenseQuery(
    queryOptions({ queryKey: ["mentor-students"], queryFn: () => listStudents() }),
  );

  const addStudentFn = useServerFn(addStudent);
  const regenerateFn = useServerFn(regenerateInvitation);
  const revokeFn = useServerFn(revokeInvitation);
  const setStatusFn = useServerFn(setStudentStatus);
  const deleteFn = useServerFn(deleteStudent);

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["mentor-students"] });

  const [addOpen, setAddOpen] = React.useState(false);
  const [newName, setNewName] = React.useState("");
  const [newYear, setNewYear] = React.useState("");
  const [codeShown, setCodeShown] = React.useState<{ code: string; expiresAt: string } | null>(null);
  const [deleteTarget, setDeleteTarget] = React.useState<StudentRow | null>(null);

  const addMutation = useMutation({
    mutationFn: (input: { displayName: string; yearGroup: string }) =>
      addStudentFn({ data: input }),
    onSuccess: (res) => {
      setAddOpen(false);
      setNewName("");
      setNewYear("");
      setCodeShown({ code: res.code, expiresAt: res.expiresAt });
      void refresh();
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  const regenerateMutation = useMutation({
    mutationFn: (studentId: string) => regenerateFn({ data: { studentId } }),
    onSuccess: (invite) => {
      setCodeShown({ code: invite.code, expiresAt: invite.expiresAt });
      void refresh();
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  const revokeMutation = useMutation({
    mutationFn: (studentId: string) => revokeFn({ data: { studentId } }),
    onSuccess: () => {
      toast.success("Invitation code revoked.");
      void refresh();
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  const statusMutation = useMutation({
    mutationFn: (input: { studentId: string; status: "active" | "archived" }) =>
      setStatusFn({ data: input }),
    onSuccess: () => void refresh(),
    onError: (err) => toast.error(errorMessage(err)),
  });

  const deleteMutation = useMutation({
    mutationFn: (input: { studentId: string; confirmName: string }) => deleteFn({ data: input }),
    onSuccess: () => {
      toast.success("Student deleted.");
      setDeleteTarget(null);
      void refresh();
    },
    onError: (err) => toast.error(errorMessage(err)),
  });

  const active = students.filter((s) => s.status !== "archived");
  const archived = students.filter((s) => s.status === "archived");

  return (
    <div>
      <PageHeader title="Students" subtitle="Add students from scratch and track who has joined.">
        <Button onClick={() => setAddOpen(true)}>Add student</Button>
      </PageHeader>

      {students.length === 0 ? (
        <EmptyState
          title="No students yet"
          message="Add your first student and Verdict Support will create a one-time invitation code they can use to join."
        >
          <Button onClick={() => setAddOpen(true)}>Add your first student</Button>
        </EmptyState>
      ) : (
        <div className="overflow-hidden rounded-lg border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Year</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last debate</TableHead>
                <TableHead className="w-12" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...active, ...archived].map((s) => {
                const status = statusOf(s);
                return (
                  <TableRow key={s.id} className={status === "archived" ? "opacity-60" : undefined}>
                    <TableCell>
                      <Link
                        to="/mentor/students/$id"
                        params={{ id: s.id }}
                        className="font-medium text-foreground underline-offset-4 hover:underline"
                      >
                        {s.display_name}
                      </Link>
                      {s.current_goal ? (
                        <p className="mt-0.5 max-w-xs truncate text-[13px] text-muted-foreground">
                          Goal: {s.current_goal}
                        </p>
                      ) : null}
                    </TableCell>
                    <TableCell>{s.year_group}</TableCell>
                    <TableCell>
                      <StatusBadge status={status} />
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {s.last_debate_date ? formatDate(s.last_debate_date) : "Not assessed yet"}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" aria-label={`Actions for ${s.display_name}`}>
                            ···
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link to="/mentor/students/$id" params={{ id: s.id }}>
                              View profile
                            </Link>
                          </DropdownMenuItem>
                          {status !== "joined" && status !== "archived" ? (
                            <DropdownMenuItem
                              onSelect={() => regenerateMutation.mutate(s.id)}
                              disabled={regenerateMutation.isPending}
                            >
                              {status === "invited" ? "New code (revokes old)" : "Generate code"}
                            </DropdownMenuItem>
                          ) : null}
                          {status === "invited" ? (
                            <DropdownMenuItem
                              onSelect={() => revokeMutation.mutate(s.id)}
                              disabled={revokeMutation.isPending}
                            >
                              Revoke code
                            </DropdownMenuItem>
                          ) : null}
                          <DropdownMenuSeparator />
                          {status === "archived" ? (
                            <DropdownMenuItem
                              onSelect={() => statusMutation.mutate({ studentId: s.id, status: "active" })}
                            >
                              Restore student
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem
                              onSelect={() => statusMutation.mutate({ studentId: s.id, status: "archived" })}
                            >
                              Archive
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem
                            className="text-destructive focus:text-destructive"
                            onSelect={() => setDeleteTarget(s)}
                          >
                            Delete…
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Add student */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add a student</DialogTitle>
            <DialogDescription>
              You'll get a one-time invitation code for them to join with their own email and password.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-2">
            <Label className="mb-1.5 block text-sm">Name</Label>
            <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="e.g. Amara Okafor" />
          </div>
          <div className="mt-3">
            <Label className="mb-1.5 block text-sm">Year group</Label>
            <Select value={newYear} onValueChange={setNewYear}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a year group" />
              </SelectTrigger>
              <SelectContent>
                {YEAR_GROUPS.map((y) => (
                  <SelectItem key={y} value={y}>
                    {y}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setAddOpen(false)}>
              Cancel
            </Button>
            <Button
              disabled={addMutation.isPending || !newName.trim() || !newYear}
              onClick={() => addMutation.mutate({ displayName: newName, yearGroup: newYear })}
            >
              {addMutation.isPending ? "Adding…" : "Add student"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Freshly generated code */}
      {codeShown ? (
        <CodeDialog
          open={!!codeShown}
          code={codeShown.code}
          expiresAt={codeShown.expiresAt}
          onOpenChange={(open) => {
            if (!open) setCodeShown(null);
          }}
        />
      ) : null}

      {/* Delete with typed confirmation */}
      <ConfirmDialog
        open={!!deleteTarget}
        title={`Delete ${deleteTarget?.display_name ?? ""}?`}
        description="This permanently removes the student, their debates, feedback and reflections. This cannot be undone."
        confirmLabel="Delete student"
        requireText={deleteTarget?.display_name ?? ""}
        onConfirm={() =>
          deleteMutation.mutateAsync({ studentId: deleteTarget!.id, confirmName: deleteTarget!.display_name })
        }
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null);
        }}
      />
    </div>
  );
}
