import { createFileRoute } from "@tanstack/react-router";
import { AuthShell, SignInForm } from "@/components/auth";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/mentor/login")({
  head: () => ({
    meta: [
      { title: "Mentor sign-in — Verdict Support" },
      { name: "description", content: "Sign in to the Verdict Support mentor portal." },
      { property: "og:title", content: "Mentor sign-in — Verdict Support" },
      { property: "og:description", content: "Sign in to the Verdict Support mentor portal." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MentorLogin,
});

function MentorLogin() {
  return (
    <AuthShell
      title="Mentor sign-in"
      subtitle="Welcome back. Sign in to your mentor portal."
      footer={
        <>
          New here?{" "}
          <Link to="/mentor/setup" className="font-medium text-foreground underline underline-offset-4">
            Set up your club
          </Link>
          {" · "}
          <Link to="/" className="hover:text-foreground">
            Back to home
          </Link>
        </>
      }
    >
      <SignInForm portal="mentor" />
    </AuthShell>
  );
}
