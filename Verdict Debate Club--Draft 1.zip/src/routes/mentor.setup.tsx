import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { setupMentor } from "@/lib/api/auth.functions";
import { AuthShell, Field, errorMessage } from "@/components/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/mentor/setup")({
  head: () => ({
    meta: [
      { title: "Set up your club — Verdict Support" },
      { name: "description", content: "Create your mentor account and debate club." },
      { property: "og:title", content: "Set up your club — Verdict Support" },
      { property: "og:description", content: "Create your mentor account and debate club." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MentorSetup,
});

function MentorSetup() {
  const navigate = useNavigate();
  const [mode, setMode] = React.useState<"founder" | "co-mentor">("founder");
  const [clubName, setClubName] = React.useState("");
  const [setupCode, setSetupCode] = React.useState("");
  const [inviteCode, setInviteCode] = React.useState("");
  const [displayName, setDisplayName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await setupMentor({
        data: {
          mode,
          code: mode === "founder" ? setupCode : inviteCode,
          ...(mode === "founder" ? { clubName } : {}),
          email,
          password,
          displayName,
        },
      });
      // The account was just created, so signing in with the same password works.
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      if (signInError) {
        // Rare: account exists but sign-in failed — send them to sign in manually.
        await navigate({ to: "/mentor/login" });
        return;
      }
      await navigate({ to: "/mentor" });
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell
      title="Set up your club"
      subtitle={
        mode === "founder"
          ? "Create the first mentor account for your debate club."
          : "Join a club as a co-mentor using your invitation code."
      }
      footer={
        <>
          Already have an account?{" "}
          <Link to="/mentor/login" className="font-medium text-foreground underline underline-offset-4">
            Sign in
          </Link>
        </>
      }
    >
      <div className="mb-5 grid grid-cols-2 gap-2 rounded-lg bg-muted p-1">
        <button
          type="button"
          onClick={() => setMode("founder")}
          className={
            "rounded-md px-3 py-2 text-sm font-medium transition-colors " +
            (mode === "founder"
              ? "bg-card text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground")
          }
        >
          I'm founding a club
        </button>
        <button
          type="button"
          onClick={() => setMode("co-mentor")}
          className={
            "rounded-md px-3 py-2 text-sm font-medium transition-colors " +
            (mode === "co-mentor"
              ? "bg-card text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground")
          }
        >
          I have a mentor invite
        </button>
      </div>

      <form onSubmit={handleSubmit}>
        {mode === "founder" ? (
          <>
            <Field label="Club name">
              <Input
                value={clubName}
                onChange={(e) => setClubName(e.target.value)}
                placeholder="e.g. Westminster Debate Society"
                required
              />
            </Field>
            <Field label="Setup code" hint="The founder code you were given when the club tracking was created.">
              <Input
                value={setupCode}
                onChange={(e) => setSetupCode(e.target.value)}
                placeholder="e.g. VDT-FOUNDER-7391"
                required
              />
            </Field>
          </>
        ) : (
          <Field label="Mentor invitation code" hint="Ask an existing mentor at your club for this code.">
            <Input
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
              required
            />
          </Field>
        )}
        <Field label="Your name">
          <Input
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            placeholder="e.g. Priya Sharma"
            required
          />
        </Field>
        <Field label="Email">
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            required
          />
        </Field>
        <Field label="Password" hint="At least 8 characters.">
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
            required
          />
        </Field>
        {error ? <p className="mb-4 text-sm text-destructive">{error}</p> : null}
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Setting up…" : mode === "founder" ? "Create my club" : "Join as co-mentor"}
        </Button>
      </form>
    </AuthShell>
  );
}
