# Verdict Support — build roadmap

## Done
- [x] Lovable Cloud enabled, email/password auth enabled
- [x] Database schema + RLS + founder code seed (migration 0000)
- [x] Server functions (auth provisioning, mentor ops, student ops, invitation redemption)
- [x] Portal chooser (/), mentor login/setup, student join + login, reset password
- [x] Mentor portal layout (nav, sign out, role guard) + dashboard
- [x] Mentor students: add student, invitation codes (generate/regenerate/revoke), archive/restore, typed-confirm delete
- [x] Student profile: debates, skill observations, feedback, reflections (respond)
- [x] Minimal student portal home (empty states)

## In progress
- [ ] End-to-end verification (mentor setup, add student, join, record progress, access rules)

## Open / waiting
- [ ] Mentor debates page (create/edit/delete debates with participants)
- [ ] Mentor feedback & reflections inbox pages
- [ ] Mentor motions library + assignments page
- [ ] Mentor settings (club name, co-mentor invites, rotate setup code, export data, delete club)
- [ ] Student portal: profile (goal/interests), reflection writing, progress, motions views
